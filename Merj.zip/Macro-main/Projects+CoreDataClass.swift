//
//  Projects+CoreDataClass.swift
//  Macro
//
//  Created by Felicia Graciella on 11/10/23.
//
//

import Foundation
import CoreData

@objc(Projects)
public class Projects: NSManagedObject {

}

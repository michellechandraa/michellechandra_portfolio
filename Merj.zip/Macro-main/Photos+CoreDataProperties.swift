//
//  Photos+CoreDataProperties.swift
//  Macro
//
//  Created by Felicia Graciella on 11/10/23.
//
//

import Foundation
import CoreData


extension Photos {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photos> {
        return NSFetchRequest<Photos>(entityName: "Photos")
    }
    
    @NSManaged public var dateCreated: Date?
    @NSManaged public var dateDeleted: Date?
    @NSManaged public var del: Bool
    @NSManaged public var id: UUID?
    @NSManaged public var link: String?
    @NSManaged public var note: String?
    @NSManaged public var photo: Data?
    @NSManaged public var ownedBy: Projects?

    
//    public var unwrappedPhoto: Data {
//        photo ?? "unknown"
//    }

}

extension Photos : Identifiable {

}

extension Photos {
    static func getAllPhotos() -> [Photos] {
        let fetchRequest: NSFetchRequest<Photos>
        fetchRequest = Photos.fetchRequest()

        fetchRequest.sortDescriptors = [
            NSSortDescriptor(keyPath: \Photos.dateCreated, ascending: false)
        ]
        
//        fetchRequest.predicate = NSPredicate(
//            format: "name != %@", selectedProject ?? ""
//        )
        
//        fetchRequest.fetchLimit = 5
        
        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return []
            } else {
                return result
            }
        } catch {
            return []
        }
    }
    
    static func getDeletedPhotos() -> [Photos]? {
        let fetchRequest: NSFetchRequest<Photos>
        fetchRequest = Photos.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "del == true"
        )
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Photos.dateDeleted, ascending: false)]

        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return nil
            } else {
                return result
            }
        } catch {
            return nil
        }
    }
}

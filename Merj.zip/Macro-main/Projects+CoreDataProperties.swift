//
//  Projects+CoreDataProperties.swift
//  Macro
//
//  Created by Felicia Graciella on 11/10/23.
//
//

import Foundation
import CoreData


extension Projects {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Projects> {
        return NSFetchRequest<Projects>(entityName: "Projects")
    }

    @NSManaged public var dateCreated: Date?
    @NSManaged public var dateModified: Date?
    @NSManaged public var dateDeleted: Date?
    @NSManaged public var del: Bool
    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var haveSome: NSSet?
    
    public var wrappedName: String {
        name ?? "Unknown Project"
    }
    
    public var photoArray : [Photos] {
        let set = haveSome as? Set<Photos> ?? []
        
        let filteredSet = set.filter { photo in
                // Add your condition here
                // For example, filter photos created in the last 7 days
                return photo.del == false
            }
        
        return filteredSet.sorted {
            $0.dateCreated ?? Date() < $1.dateCreated ?? Date()
        }
    }
}

// MARK: Generated accessors for haveSome
extension Projects {

    @objc(addHaveSomeObject:)
    @NSManaged public func addToHaveSome(_ value: Photos)

    @objc(removeHaveSomeObject:)
    @NSManaged public func removeFromHaveSome(_ value: Photos)

    @objc(addHaveSome:)
    @NSManaged public func addToHaveSome(_ values: NSSet)

    @objc(removeHaveSome:)
    @NSManaged public func removeFromHaveSome(_ values: NSSet)

}

extension Projects : Identifiable {
    
}

enum SortBy: String, CaseIterable {
    case title = "A-Z"
    case lastModified = "Last Modified"
    case lastCreated = "Last Created"
}

extension Projects {
    static func getAllProject(filter: String, sortBy: SortBy = .lastModified, selectedProject: String?) -> [Projects] {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()
        
        if filter != "" {
            fetchRequest.predicate = NSPredicate(
                format: "name CONTAINS[cd] %@ AND name != %@ AND del == false", filter, selectedProject ?? ""
            )
        } else {
            fetchRequest.predicate = NSPredicate(
                format: "name != %@ AND del == false", selectedProject ?? ""
            )
        }
        
        
        /// - SORT BY
        switch sortBy {
            case .title:
                fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.name, ascending: true)]
            case .lastCreated:
                fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.dateCreated, ascending: false)]
            case .lastModified:
                fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.dateModified, ascending: false)]
        }
        
        
        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return []
            } else {
                return result
            }
        } catch {
            return []
        }
    }
    
    
    
    static func getSpecificProject(filter: String) -> Projects? {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "name LIKE %@ AND del == false", filter
        )
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.dateDeleted, ascending: false)]

        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return nil
            } else {
                return result[0]
            }
        } catch {
            return nil
        }
    }
    
    static func getSpecificDeletedCollection(filter: String) -> Projects? {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "name LIKE %@ AND del == true", filter
        )
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.dateDeleted, ascending: false)]

        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return nil
            } else {
                return result[0]
            }
        } catch {
            return nil
        }
    }
    
    static func getDeletedProjects() -> [Projects]? {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "del == true"
        )
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Projects.dateDeleted, ascending: false)]

        let context = DataProvider.shared.viewContext

        do {
            
            let result = try context.fetch(fetchRequest)
            if result.isEmpty {
                return nil
            } else {
                return result
            }
        } catch {
            return nil
        }
    }
}

//class ProjectManager: ObservableObject {
//
//    @Published var projects: [Projects] = Projects.getAllProject(filter: "", sortBy: SortBy(rawValue: "") ?? .lastModified, selectedProject: "", limit: false)
//    
////    @Published var projectFive: [Projects] = Projects.getFiveProject(filter: "", selectedProject: "")
//
//    // Add methods to create folders and manage projects
//    
//    func getFive(filter: String, selectedProject: String) {
//        projects = Projects.getAllProject(filter: filter, sortBy: .lastModified, selectedProject: "", limit: false)
//    }
//    
//    func createFolder(folderName: String, moc: NSManagedObjectContext) {
//            let project1 = Projects(context: moc)
//            project1.name = folderName
//            project1.id = UUID()
//            project1.dateCreated = Date() // Assuming you meant to use Date() here
//            project1.dateModified = Date() // Assuming you meant to use Date() here
//
//            do {
//                try moc.save()
//                print("Folder saved")
////                projects = Projects.getFiveProject(filter: "", selectedProject: "")
//            } catch let error as NSError {
//                print("Could not save folder. \(error), \(error.userInfo)")
//            }
//        }
//    
//    func filterFolder(filter: String, sortBy: SortBy) {
//        projects = Projects.getAllProject(filter: filter, sortBy: sortBy, selectedProject: "", limit: false)
//    }
//}

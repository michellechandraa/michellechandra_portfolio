//
//  Photos+CoreDataClass.swift
//  Macro
//
//  Created by Felicia Graciella on 11/10/23.
//
//

import Foundation
import CoreData

@objc(Photos)
public class Photos: NSManagedObject {

}

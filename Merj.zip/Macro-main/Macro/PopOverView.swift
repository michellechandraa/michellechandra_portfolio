//
//  PopOverView.swift
//  Macro
//
//  Created by Felicia Graciella on 15/11/23.
//

import SwiftUI

struct PopOverView: View {
    var text: String
    
    var body: some View {
        Text(text)
            .font(.callout)
            .padding(.vertical, 10)
            .padding(.horizontal, 10)
            .frame(minWidth: 100)
    }
    
}

#Preview {
    PopOverView(text: "Click + to create a Collection!")
}

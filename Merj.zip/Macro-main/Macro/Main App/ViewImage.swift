//
//  ViewImage.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 30/10/23.
//

import SwiftUI

struct ViewImage: View {
    @ObservedObject var viewModel: RootViewModel
    
    @Environment(\.openURL) var openURL
    @EnvironmentObject var appState: AppState
    @Binding var currentImageIndex: Int
    @Binding var showViewImage: Bool
    
    @Environment(\.dismiss) var dismiss
    
    var window = NSScreen.main?.visibleFrame
    var selectedFolder: Projects!

    @State var moc = DataProvider.shared.viewContext
    
    @State var selectedPhoto: Photos!
    
    @State private var showingDeleteAlert = false
    
    var title: String
    
    @State var addNotes = false
    
    var body: some View {
        // NavigationStack {
        ZStack {
            VStack {
                /// CLOSE, DELETE, SHARE
                HStack {
                    
                    /// CLOSE
                    Button(action: {
                        withAnimation{
                            dismiss()
                        }
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                            .scaledToFit()
                            .frame(width: window!.width/70, alignment: .leading)
                    })
                    .buttonStyle(PlainButtonStyle())
                    
                    Text("Preview")
                    
                    Spacer()
                    
                    Button(action: {
                        withAnimation{
                            addNotes = true
                        }
                        
                        
                    }, label: {
                        Image(systemName: "square.and.pencil")
                            .foregroundColor(.gray)
                            .scaledToFit()
                            .frame(width: window!.width/70, alignment: .leading)
                        
                    })
                    .disabled(selectedFolder.photoArray[currentImageIndex].note != "")
                    .buttonStyle(.plain)
                    
                    /// DELETE
                    Button(action: {
                        showingDeleteAlert = true
                        
                    }, label: {
                        Image(systemName: "trash")
                            .foregroundColor(.gray)
                            .scaledToFit()
                            .frame(width: window!.width/70, alignment: .leading)
                        
                    })
                    .buttonStyle(.plain)
                    
                    /// SHARE
                    if currentImageIndex < selectedFolder.photoArray.count,
                       let data = selectedFolder.photoArray[currentImageIndex].photo {
                        
                        ShareLink(item:
                                    Image(nsImage: NSImage(data: selectedFolder.photoArray[currentImageIndex].photo ?? Data()) ?? NSImage()),
                                    
                                  preview:
                                    SharePreview(selectedFolder.photoArray[currentImageIndex].link ?? "",
                                                 image: Image(nsImage: NSImage(data: selectedFolder.photoArray[currentImageIndex].photo ?? Data()) ?? NSImage()))) {
                            Image(systemName: "square.and.arrow.up")
                                .foregroundColor(.gray)
                                .scaledToFit()
                                .frame(width: window!.width/70, alignment: .leading)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    
                }
                .padding(.top, 10)
                .padding(.horizontal,10)
                
                Spacer()
                
                /// IMAGE AND NAVIGATION
                HStack{
                    /// LEFT
                    Button(action: {
                        if currentImageIndex < selectedFolder.photoArray.count - 1 {
                            currentImageIndex = currentImageIndex + 1
                        }
                    }, label: {
                        Image(systemName: "chevron.compact.left")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 48)
                            .padding(.horizontal, 20)
                            .opacity(0.8)
                    })
                    .disabled(currentImageIndex >= selectedFolder.photoArray.count - 1)
                    .buttonStyle(.borderless)
                    .keyboardShortcut(.leftArrow, modifiers: [])
                    
                    Spacer()
                    
                    /// LINK AND IMAGE
//                    VStack (alignment: .leading){
//                        
//                        if currentImageIndex < selectedFolder.photoArray.count,
//                           let data = selectedFolder.photoArray[currentImageIndex].photo {
//                            
//                            Image(nsImage: NSImage(data:  selectedFolder.photoArray[currentImageIndex].photo ?? Data()) ?? NSImage())
//                                .resizable()
//                                .scaledToFit()
//                                .background(.clear)
//                                .clipShape(Rectangle())
//                                .cornerRadius(4)
//                                .shadow(color: Color.gray.opacity(0.05), radius: 5, x: 10, y: 10)
////                                .padding(.bottom)
//                            
//                            HStack {
//                                if selectedFolder.photoArray[currentImageIndex].link != nil {
//                                    Button {
//                                        openURL(URL(string: selectedFolder.photoArray[currentImageIndex].link ?? "https://www.google.com/")!)
//                                    } label: {
//                                        HStack {
//                                            Image(systemName: "arrow.up.right")
//                                            
//                                            Text("Go to source")
//                                                .underline()
//                                        }
//                                        .background(.clear)
//                                        .foregroundColor(Color("StrongOrange"))
//                                        .buttonStyle(.plain)
//                                    }
//                                    .buttonStyle(.plain)
//                                    .padding(.bottom, 10)
//                                } else {
//                                    Text("No link attached.")
//                                        .foregroundStyle(.gray)
//                                        .padding(.bottom, 10)
//                                }
//                                
//                                Spacer()
//                            }
//                            
//                        }
//                    }
//                    .frame(width: window!.width/2.2)
//                    
//                    Spacer()
//                    
//                    /// RIGHT
//                    Button(action: {
//                        if currentImageIndex > 0 {
//                            currentImageIndex = currentImageIndex - 1
//                        }
//                    }, label: {
//                        Image(systemName: "chevron.compact.right")
//                            .resizable()
//                            .scaledToFit()
//                            .frame(height: 48)
//                            .padding(.horizontal, 20)
//                            .opacity(0.8)
//                    })
//                    .buttonStyle(.borderless)
//                    .keyboardShortcut(.rightArrow, modifiers: [])
                    
                    VStack(alignment: .leading){
                                            
                        if currentImageIndex < selectedFolder.photoArray.count,
                            let data = selectedFolder.photoArray[currentImageIndex].photo {
                            Image(nsImage: NSImage(data:  selectedFolder.photoArray[currentImageIndex].photo ?? Data()) ?? NSImage())
                                .resizable()
                                .scaledToFit()
                                .background(.clear)
                                .clipShape(Rectangle())
                                .cornerRadius(4)
                                .shadow(color: Color.gray.opacity(0.05), radius: 5, x: 10, y: 10)
                            
                            if selectedFolder.photoArray[currentImageIndex].link != nil {
                                Button {
                                    openURL(URL(string: selectedFolder.photoArray[currentImageIndex].link ?? "https://www.google.com/")!)
                                } label: {
                                    HStack {
                                        Image(systemName: "arrow.up.right")
                                        
                                        Text("Go to source")
                                            .underline()
                                    }
                                    .background(.clear)
                                    .foregroundColor(Color("StrongOrange"))
                                    .buttonStyle(.plain)
                                }
                                .buttonStyle(.plain)
                                .padding(.top, 10)
                                .padding(.bottom, 20)
                                
                            }
                        }
                        else{
                            Text("No link attached.")
                                .foregroundStyle(.gray)
                                .padding(.top, 10)
                                .padding(.bottom, 20)
                        }
                    }
                    .frame(width: window!.width/2.2)
                    
                    Spacer()
                    
                    Button(action: {
                        if currentImageIndex > 0 {
                            currentImageIndex = currentImageIndex - 1
                        }
                        
                        print(selectedFolder.photoArray[currentImageIndex].ownedBy?.name)
                        
                    }, label: {
                        Image(systemName: "chevron.right")
                            .resizable()
                            .scaledToFit()
                            .frame(width: window!.width/80)
                            .padding(.horizontal, 20)
                            .opacity(0.8)
                    })
                    .buttonStyle(.borderless)
                    .keyboardShortcut(.rightArrow, modifiers: [])
                    
                }
                
                Spacer()

            }
            .frame(width: window!.width/1.3, height: window!.height/1.2)
            .background(.ultraThinMaterial)

            VStack {
                HStack {
                    Spacer()
                    
                    if selectedFolder.photoArray[currentImageIndex].note == "" && addNotes == true {
                        HStack {
                            TextField("Add note", text: $viewModel.notes, axis: .vertical)
                                .onChange(of: viewModel.notes) { newValue in
                                    if viewModel.notes.count > 100 {
                                        viewModel.notes = String(viewModel.notes.prefix(100))
                                    }
                                }
                                .onSubmit {
                                    withAnimation(.easeOut(duration: 0.3)) {
                                        viewModel.addNote(photo: selectedFolder.photoArray[currentImageIndex])
                                        
                                        viewModel.notes = ""
                                        addNotes = false
                                    }
                                }
                            
                            Spacer()
                            
                            VStack(alignment: .trailing) {
//                                Spacer()
                                
                                Text("\(viewModel.notes.count)/100")
                                    .font(.system(size: 8))
                            }
                        }
                        .frame(width: 180)
                        .padding(4)
                        .background(Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                            .cornerRadius(4)
                            .overlay( /// apply a rounded border
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                            ))
                        .padding(.trailing, 20)
                        .padding(.top, 60)
                        
                    } else if selectedFolder.photoArray[currentImageIndex].note != "" && addNotes == true{
                        HStack {
                            TextField("Edit note", text: $viewModel.notes, axis: .vertical)
                                .onChange(of: viewModel.notes) { newValue in
                                    if viewModel.notes.count > 100 {
                                        viewModel.notes = String(viewModel.notes.prefix(100))
                                    }
                                }
                                .onSubmit {
                                    withAnimation(.smooth(duration: 0.3)) {
                                        viewModel.addNote(photo: selectedFolder.photoArray[currentImageIndex])
                                        
                                        viewModel.notes = ""
                                        addNotes = false
                                    }
                                }
//                                                        .padding()
                            
                            Spacer()
                            
                            VStack(alignment: .trailing) {
//                                Spacer()
                                
                                Text("\(viewModel.notes.count)/100")
                                    .font(.system(size: 8))
                            }
                        }
                        .frame(width: 180)
                        .padding(4)
                        .background(Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                            .cornerRadius(4)
                            .overlay( /// apply a rounded border
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                            ))
                        .padding(.trailing, 20)
                        .padding(.top, 60)
                    } else if selectedFolder.photoArray[currentImageIndex].note != "" && selectedFolder.photoArray[currentImageIndex].note != nil {
                        HStack {
                            Text("\(selectedFolder.photoArray[currentImageIndex].note ?? "")")
                                .multilineTextAlignment(.leading)
        //                        .lineLimit(2)
                            
                            Spacer()
                                
                            VStack(alignment: .trailing, spacing: 40) {
                                Button {
                                    withAnimation(.easeOut(duration: 0.3)) {
                                        addNotes = true
                                        viewModel.notes = selectedFolder.photoArray[currentImageIndex].note ?? ""
                                    }
                                } label: {
                                    ZStack {
                                        Rectangle()
                                            .fill(.white)
                                            .opacity(0.1)
                                            .cornerRadius(4)
                                            
                                        Image(systemName: "pencil")
                                            .padding(4)
                                    }
                                    
                                }
                                .frame(width: 15, height: 15)
                                .buttonStyle(.plain)
                                .padding([.top, .horizontal], 4)
                                
    //                            Spacer()
                                
                                Text("\(selectedFolder.photoArray[currentImageIndex].note?.count ?? 0)/100")
                                    .font(.system(size: 8))
                            }
                        }
                        .frame(width: 180)
                        .padding(4)
                        .background(Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                            .cornerRadius(4)
                            .overlay( /// apply a rounded border
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                            ))
                        .padding(.trailing, 20)
                        .padding(.top, 60)
                    }
                    
                    
                }
                
                Spacer()
            }
            
            
            
        }
        .alert(
            "Delete from \(title)?",
            isPresented: $showingDeleteAlert
        ) {
            Button("Delete", role: .destructive) {
                withAnimation {
                    do {
                        if let managedObject = try DataProvider.shared.viewContext.existingObject(with: selectedFolder.photoArray[currentImageIndex].objectID) as! Photos? {
                            
                            selectedPhoto = managedObject
                        }
                    } catch {
                        print(error)
                    }
                    
                    selectedPhoto.del = true
                    selectedPhoto.dateDeleted = Date.now
                    
                    do {
                        try moc.save()
                        print("saved")
                        
                    } catch let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                    }
                    
                    showViewImage.toggle()
                    
                    showingDeleteAlert = false
                    
                    viewModel.getAllProjectinApp()
                }
            }
        }
        .frame(maxWidth: window!.width/1.1)
        .background(VisualEffectView(material: .hudWindow, blendingMode: .withinWindow))
    }
}


//struct ViewImage_Previews: PreviewProvider {
//    static var previews: some View {
//        ViewImage(currenImageIndex: .constant(0))
//    }
//}

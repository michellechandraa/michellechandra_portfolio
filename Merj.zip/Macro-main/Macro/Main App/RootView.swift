//
//  ContentView.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI
import AVKit

//TES

struct RootView: View/*, DropDelegate*/ {
    @Binding var isPopoverPartFour: Bool
    @Binding var isPopoverPartFive: Bool
    
    @StateObject var viewModel: RootViewModel = RootViewModel()
    @ObservedObject var panelVM: FloatingPanelViewModel = FloatingPanelViewModel()
    
    @State var newEntryPanel: FloatingPanelSettings<FloatingPanelView>!
    
    /// - Window size
    var window = NSScreen.main?.visibleFrame
    
    @State var hoverStatus: Bool = false
    
    /// - Navigation
    @EnvironmentObject private var appState: AppState
    @State private var currentSubview = AnyView(ContentView())
    @State private var showingSubview = false
    var body: some View {
        /// Side Bar
        NavigationSplitView{
            SideBar()
                .onChange(of: appState.currentRoute) { oldValue, newValue in
                    showingSubview = false
                }
        } detail: {
            StackBarNavigationView(currentSubview: $currentSubview, showingSubview: $showingSubview){
                if let currentRoute = appState.currentRoute {
                    switch currentRoute {
                    case .allProjects:
                        AllProjectsView(viewModel: viewModel, currentSubview: $currentSubview, showingSubview: $showingSubview)

                    case .recentlyDeleted:
                        RecentlyDeletedView(viewModel: viewModel, currentSubview: $currentSubview, showingSubview: $showingSubview)
                    }
                }
                
                
            }
            .frame(minWidth: window!.height/2.8)
            .navigationTitle("")
            .onAppear {
                panelVM.getLastProject()
                
                if UserDefaults.standard.bool(forKey: "fromPanel") == true {
                    print("ROOTVIEW \(panelVM.lastProject?.name)")
                    
                    currentSubview = AnyView(InsideFolderView(viewModel: RootViewModel(), selectedFolder: panelVM.lastProject, currentSubview: $currentSubview, showingSubview: $showingSubview, title: panelVM.lastProject?.wrappedName ?? ""))
                    showingSubview = true
                    
                    UserDefaults.standard.set(false, forKey: "fromPanel")
                }
            }
            .navigationTitle("")
            .toolbarTitleDisplayMode(.inlineLarge)
            .toolbar {
                ToolbarItem(placement: .navigation) {
                    Button {
                        NSApplication.shared.mainWindow?.close()
                        
                        newEntryPanel = FloatingPanelSettings(view:
                                                                FloatingPanelView(isPopoverPartOne: false, isPopoverPartTwo: false, isPopoverPartThree: false)
                        )
                        
                        // CHANGE USERDEFAULTS TO 4
                        if UserDefaults.standard.integer(forKey: "onboardingStatus") == 3 {
                            UserDefaults.standard.set(4, forKey: "onboardingStatus")
                            
                        }
                    } label: {
                        Image(systemName: "pip.enter")
                            .font(.caption2)
                            .foregroundColor(hoverStatus ? Color("StrongOrange") : .primary)
                    }
                    .onHover(perform: { hovering in
                        self.hoverStatus = hovering
                    })
                    .popover(isPresented: self.$isPopoverPartFour, arrowEdge: .bottom) {
                        PopOverView(text: "Click to access the panel")
                    }
                }
            }
        }
        
    }
}

//struct HomeView_Previews: PreviewProvider {
//    static var previews: some View {
//        RootView()
//    }
//}

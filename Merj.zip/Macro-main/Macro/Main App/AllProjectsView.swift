//
//  AllProjectsView.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct AllProjectsView: View {
    @ObservedObject var viewModel: RootViewModel
    
    var window = NSScreen.main?.visibleFrame
    @EnvironmentObject var appState: AppState
    @Binding var currentSubview: AnyView
    @Binding var showingSubview: Bool
    
    @State var selectedProjectInApp: Projects?
    
    @State var moc = DataProvider.shared.viewContext
    
    /// New Folder text field
    @State var showTextField = false
    @FocusState var textFieldIsFocused: Bool
    
    /// - sorting
    @State private var sortBy: SortBy = .lastModified
    
    //onHover
    @State var hoverStatus: Bool = false
    
    @State var collectionAlreadyExists: Bool = false
    
    /// DELETE ALERT
    @State private var showingDeleteAlert = false
    
    /// RENAME TEXTFIELD
    @State private var showingRenameTextField = false
    
    var body: some View {
//        ScrollView(.vertical) {
        VStack {
            Group {
                if viewModel.searchText != "" {
                    Text(viewModel.resultText)
                        .font(.system(size: 16))
                        .fontWeight(.medium)
                        
                } else {
                    Text("All Collections")
                        .fontWeight(.bold)
                        .font(.title)
                }
            }
            .padding([.top, .leading])
            .frame(maxWidth: .infinity, alignment: .leading)

            
            if viewModel.allProject.count != 0 {
                ScrollView(.vertical) {
                
//                    lazy
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 195, maximum: 195), spacing: 12)], alignment: .leading, spacing: 12) {
//                    LazyVGrid(columns: [GridItem(.fixed(200), spacing: 16)], spacing: 16) {
                        
                        /// NEW COLLECTION
                        if(showTextField == true) {
                            ZStack {
                                FolderThumbnail(image: nil, title: "", selectedFolder: nil)
                                
                                VStack {
                                    Spacer()
                                    TextField("New Folder", text: $viewModel.newProject)
                                        .textFieldStyle(.plain)
                                        .onSubmit {
                                            if !viewModel.newProject.isEmpty {
                                                
                                                viewModel.saveProject()
                                                
                                                if !viewModel.collectionAlreadyExist {
                                                    collectionAlreadyExists = false
                                                    viewModel.pinProject(projectName: viewModel.newProject)
                                                }
                                                
                                                print(viewModel.newProject)
                                                
                                            }
                                            
                                            showTextField.toggle()
                                            viewModel.newProject = ""
                                            
                                        }
                                        .foregroundColor(.black)
                                        .frame(width: 160)
                                        .focused($textFieldIsFocused)
                                        .padding(.bottom, 24)
                                }
                                
                                VStack {
                                    HStack {
                                        Spacer()
                                        
                                        Button {
                                            showTextField.toggle()
                                            viewModel.newProject = ""
                                        } label: {
                                            ZStack {
                                                VisualEffectView(material: .dark, blendingMode: .withinWindow)
                                                
                                                Image(systemName: "x.circle")
                                                    .foregroundColor(.white)
                                                    .font(.title3)
                                            }
                                            .frame(width: 25, height: 25)
                                            .clipShape(Rectangle())
                                            .cornerRadius(8)
                                            .padding(8)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                    .frame(width: 200)
                                    
                                    Spacer()
                                }
                                
                            }
                        }
                        
                        
                        ForEach(viewModel.allProject, id: \.self) { project in
                        
                                Button(action: {
                                    selectedProjectInApp = project
                                    
                                    viewModel.getAllProjectinApp()
                                    
                                    withAnimation(.easeOut(duration: 0.3)) {
                                        currentSubview = AnyView(/*InsideFolderView(viewModel: viewModel, selectedFolder: selectedProjectInApp, title: project.wrappedName)*/ InsideFolderView(viewModel: viewModel, selectedFolder: selectedProjectInApp, currentSubview: $currentSubview, showingSubview: $showingSubview, title: project.wrappedName))
//                                        currentSubview = AnyView(PrintView(viewModel: viewModel, title: "Sapiman"))
                                        showingSubview = true
                                    }
                                }, label: {
                                    if(project.photoArray.count != 0) {
                                        ZStack {
                                            if showingRenameTextField == true && selectedProjectInApp == project{
                                                FolderThumbnail(image: NSImage(data: project.photoArray[(project.photoArray.count )-1].photo ?? Data())!, title: "")
                                            } else {
                                                FolderThumbnail(image: NSImage(data: project.photoArray[(project.photoArray.count )-1].photo ?? Data())!, title: project.wrappedName)
                                            }
                                            
                                            
                                            VStack {
                                                HStack {
                                                    Spacer()
                                                    
                                                    if showingRenameTextField && selectedProjectInApp == project {
                                                        Button {
                                                            showingRenameTextField.toggle()
                                                            viewModel.newProject = ""
                                                        } label: {
                                                            ZStack {
                                                                VisualEffectView(material: .dark, blendingMode: .withinWindow)
                                                                
                                                                Image(systemName: "x.circle")
                                                                    .foregroundColor(.white)
                                                                    .font(.title3)
                                                            }
                                                            .frame(width: 25, height: 25)
                                                            .clipShape(Rectangle())
                                                            .cornerRadius(8)
                                                            .padding(8)
                                                        }
                                                        .buttonStyle(.plain)
                                                    } else {
                                                        EllipsesMenu(button1Name: "Rename", button2Name: "Delete") {
                                                            selectedProjectInApp = project
                                                            
                                                            showingRenameTextField = true
                                                            textFieldIsFocused = true
                                                            
                                                            viewModel.newProject = project.wrappedName
                                                        } button2OnClick: {

                                                            selectedProjectInApp = project
                                                            showingDeleteAlert = true
                                                        }
                                                    }
                                                    
                                                }
                                                .frame(width: 200)
                                                
                                                Spacer()
                                                
                                                if showingRenameTextField == true && selectedProjectInApp == project{
                                                    VStack {
                                                        Spacer()
                                                        TextField("Rename Collection", text: $viewModel.newProject)
                                                            .textFieldStyle(.plain)
                                                            .focused($textFieldIsFocused)
                                                            .onSubmit {
                                                                if !viewModel.newProject.isEmpty {
                                                                    
                                                                    viewModel.renameCollection(collectionName: project.name ?? "", newName: viewModel.newProject)
                                                                    
                                                                    if !viewModel.collectionAlreadyExist {
                                                                        collectionAlreadyExists = false
//                                                                        viewModel.pinProject(projectName: viewModel.newProject)
                                                                    }
                                                                    
                                                                    print(viewModel.newProject)
                                                                    
                                                                }
                                                                
                                                                showingRenameTextField.toggle()
                                                                viewModel.newProject = ""
                                                                
                                                            }
                                                            .foregroundColor(.black)
                                                            .frame(width: 160)
                                                            .focused($textFieldIsFocused)
                                                            .padding(.bottom, 24)
                                                    }
                                                }
                                            }
                                        }
                                        
                                    } else {
                                        ZStack {
                                            if showingRenameTextField == true && selectedProjectInApp == project{
                                                FolderThumbnail(image: nil, title: "")
                                            } else {
                                                FolderThumbnail(image: nil, title: project.wrappedName)
                                            }
                                            
                                            VStack {
                                                HStack {
                                                    Spacer()
                                                    
                                                    if showingRenameTextField && selectedProjectInApp == project {
                                                        Button {
                                                            showingRenameTextField.toggle()
                                                            viewModel.newProject = ""
                                                        } label: {
                                                            ZStack {
                                                                VisualEffectView(material: .dark, blendingMode: .withinWindow)
                                                                
                                                                Image(systemName: "x.circle")
                                                                    .foregroundColor(.white)
                                                                    .font(.title3)
                                                            }
                                                            .frame(width: 25, height: 25)
                                                            .clipShape(Rectangle())
                                                            .cornerRadius(8)
                                                            .padding(8)
                                                        }
                                                        .buttonStyle(.plain)
                                                    } else {
                                                        EllipsesMenu(button1Name: "Rename", button2Name: "Delete") {

                                                            selectedProjectInApp = project
                                                            
                                                            showingRenameTextField = true
                                                            textFieldIsFocused = true
                                                            
                                                            viewModel.newProject = project.wrappedName
                                                        } button2OnClick: {

                                                            selectedProjectInApp = project
                                                            showingDeleteAlert = true
                                                        }
                                                    }
                                                    
                                                }
                                                .frame(width: 200)
                                                
                                                Spacer()
                                                
                                                if showingRenameTextField == true && selectedProjectInApp == project{
                                                    VStack {
                                                        Spacer()
                                                        TextField("Rename Collection", text: $viewModel.newProject)
                                                            .textFieldStyle(.plain)
                                                            .focused($textFieldIsFocused)
                                                            .onSubmit {
                                                                if !viewModel.newProject.isEmpty {
                                                                    
                                                                    viewModel.renameCollection(collectionName: project.name ?? "", newName: viewModel.newProject)
                                                                    
                                                                    if !viewModel.collectionAlreadyExist {
                                                                        collectionAlreadyExists = false
//                                                                        viewModel.pinProject(projectName: viewModel.newProject)
                                                                    }
                                                                    
                                                                    print(viewModel.newProject)
                                                                    
                                                                }
                                                                
                                                                showingRenameTextField.toggle()
                                                                viewModel.newProject = ""
                                                                
                                                            }
                                                            .foregroundColor(.black)
                                                            .frame(width: 160)
                                                            .focused($textFieldIsFocused)
                                                            .padding(.bottom, 24)
                                                    }
                                                }
                                                
                                            }
                                            
                                            
                                            
                                        }
                                        
                                    }
                                })
                                .buttonStyle(PlainButtonStyle())
//                            }
                        }
                        
                    }
                    .padding()
//                    .frame(maxWidth: .infinity, alignment: .topLeading)
//                    .ignoresSafeArea()
                    
                    Spacer()
                }
            } else {
                if(showTextField == true) {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 200), spacing: 20)], spacing: 20) {
                        
                        /// NEW COLLECTION
                        ZStack {
                            FolderThumbnail(image: nil, title: "")
                            
                            VStack {
                                Spacer()
                                
                                TextField("New Folder", text: $viewModel.newProject)
                                    .onSubmit {
                                        if !viewModel.newProject.isEmpty {
                                            
                                            viewModel.saveProject()
                                            
                                            if !viewModel.collectionAlreadyExist {
                                                collectionAlreadyExists = false
                                                viewModel.pinProject(projectName: viewModel.newProject)
                                            }
                                            
                                            print(viewModel.newProject)
                                            
                                        }
                                        
                                        showTextField.toggle()
                                        viewModel.newProject = ""
                                        
                                    }
                                    .foregroundColor(.black)
                                    .frame(width: 160)
                                    .focused($textFieldIsFocused)
                                    .padding(.bottom, 24)
                            }
                            
                        }
                        
                    }
                    .padding([.top, .horizontal])
//                    .frame(maxWidth: .infinity, alignment: .topLeading)
//                    .ignoresSafeArea()
                    
                    Spacer()
                } else if (viewModel.searchText == ""){
                    Text("Create your first Collection")
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                } else {
                    Spacer()
                }
                
            }
        }
        .searchable(text: $viewModel.searchText)
        .tint(Color("StrongOrange"))
        .alert(
            "Delete Collection?",
            isPresented: $showingDeleteAlert
        ) {
            Button("Delete", role: .destructive) {
                withAnimation {
                    
                    selectedProjectInApp?.del = true
                    selectedProjectInApp?.dateDeleted = Date.now
                    
                    
                    do {
                        try moc.save()
                        print("delete \(selectedProjectInApp?.wrappedName)")
                        
                    } catch let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                    }
                    
                    if selectedProjectInApp == viewModel.lastProject {
                        viewModel.getAllProjectinApp()
                        viewModel.lastProject = viewModel.allProject.first
                        
                        if viewModel.allProject.count != 0 {
                            UserDefaults.save(managedObjectID: viewModel.allProject.first!.objectID, with: "lastProject")
                        }
                        
                        print("pin ini \(viewModel.lastProject?.wrappedName)")
                    }
//                    viewModel.lastProject = viewModel.allProject.last
//                    print("pin ini \(viewModel.lastProject?.wrappedName)")
                    
                    showingDeleteAlert = false
                    
                    viewModel.getAllProjectinApp()
                    
                }
            }
        }
        
        .onAppear{
            viewModel.getAllProjectinApp()
        }
        
        
        
        /// - SORT BY
        .toolbar {
            ToolbarItem {
                Button {
                    showTextField.toggle()
                    textFieldIsFocused = true
                } label: {
                    Image(systemName: "plus")
                        .foregroundColor(hoverStatus ? Color("StrongOrange") : .primary)
                }
                .onHover(perform: { hovering in
                    self.hoverStatus = hovering
                })
            }
            
            ToolbarItem {
                HStack {
                    Text("Sort by: ")
                    Picker("Sort", selection: $sortBy) {
                        ForEach(SortBy.allCases, id: \.self) { sortBy in
                            Text("\(sortBy.rawValue)")
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
                
            }
        }
        
        .alert(
            "Collection already exists",
            isPresented: $viewModel.collectionAlreadyExist
        ) {
            Button("Ok", role: .cancel) {}
        }
        
        .onChange(of: sortBy) { oldValue, newValue in
            
            viewModel.getAllProjectinApp(sortBy: newValue)
        }
        
        .onChange(of: viewModel.searchText) { _, _ in

            viewModel.getAllProjectinApp(sortBy: sortBy)
        }
        
        .onChange(of: viewModel.allProject.count) { _, _ in

            viewModel.getAllProjectinApp(sortBy: sortBy)
        }
    }
    
    private func showSubview(view: AnyView) {
        withAnimation(.easeOut(duration: 0.3)) {
            currentSubview = view
            showingSubview = true
        }
    }
}


//struct AllProjectsView_Previews: PreviewProvider {
//    static var previews: some View {
//        AllProjectsView()
//    }
//}

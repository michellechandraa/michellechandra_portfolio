//
//  AppState.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import Foundation

enum Route {
    case allProjects
    case recentlyDeleted
}

class AppState: ObservableObject{
    @Published var routes: [Route] = [.allProjects]
    
    var currentRoute: Route? {
        routes.last
    }
    
    func push(_ route: Route) {
        routes.append(route)
    }
    
    @discardableResult
    func pop() -> Route? {
        routes.popLast()
    }
}

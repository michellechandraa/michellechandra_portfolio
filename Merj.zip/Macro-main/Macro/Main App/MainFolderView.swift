//
//  FloatingPanelFolderView.swift
//  Macro
//
//  Created by Felicia Graciella on 16/10/23.
//

import SwiftUI

struct MainFolderView: View {
    var projectName: String
    
    var body: some View {
        HStack {
            HStack {
                ZStack {
                    Rectangle()
                    
                    Text(projectName)
                        .foregroundColor(.black)
                        .font(.system(size: 10))
                        
                }
                .padding(0)
                    
                Rectangle()
                    .fill(.cyan)
                    .frame(width: 80)
                    .padding(0)
            }
            .background(.white)
            .frame(width: 140, height: 75)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }
}

#Preview {
    MainFolderView(projectName: "New Folder")
}

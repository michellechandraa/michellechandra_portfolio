//
//  AddThumbnail.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct AddThumbnail: View {
    var image: String
    @State var showPlus: Bool = false
    
    var body: some View {
        
        ZStack{
            Rectangle()
                .foregroundColor(.gray)
                .opacity(0.2)
            
            Image(systemName:  "plus")
                .font(.system(size: 50))
                .foregroundColor(.gray)
            
        }
        .frame(width: 200, height: 200)
        .clipShape(Rectangle())
        .cornerRadius(10)
        
        
    }
}

struct AddThumbnail_Previews: PreviewProvider {
    static var previews: some View {
        AddThumbnail(image: "plus")
    }
}

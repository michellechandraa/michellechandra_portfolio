//
//  EllipsesMenu.swift
//  Merj
//
//  Created by Felicia Graciella on 29/11/23.
//

import SwiftUI

struct EllipsesMenu: View {
    var button1Name: String
    var button2Name: String
    
    var button1OnClick: () -> Void
    var button2OnClick: () -> Void
    
    var body: some View {
        Menu {
            Button(button1Name) {
                button1OnClick()
            }
            
            Button(button2Name) {
                button2OnClick()
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .foregroundColor(.white)
                .font(.title2)
        }
        .background(VisualEffectView(material: .dark, blendingMode: .withinWindow)
            .frame(width: 25, height: 25)
            .clipShape(Rectangle())
            .cornerRadius(8)
            .padding(12))
        .buttonStyle(.borderless)
        .menuIndicator(.hidden)
        .tint(.white)
        .padding(12)
    }
}

//#Preview {
//    CollectionEllipsesMenu()
//}

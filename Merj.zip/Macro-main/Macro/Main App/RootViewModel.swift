//
//  MainViewModel.swift
//  Macro
//
//  Created by Felicia Graciella on 02/11/23.
//

import Foundation
import SwiftUI
//import AVKit

class RootViewModel: ObservableObject {
    
    @Published var lastProject: Projects?
    
    /// DATA PROVIDER
    private var moc = DataProvider.shared.viewContext
    
    /// FETCH FROM CORE DATA
    /// INI NDA PAKE
//    @Published var projects = Projects.getAllProject(filter: "", selectedProject: UserDefaults.standard.string(forKey: "lastFolder"))
    @Published var allProject = Projects.getAllProject(filter: "", selectedProject: "")
    
    
    @Published var resultText = ""
    
    /// GET PROJECTS IN APP
    func getAllProjectinApp(sortBy: SortBy = .lastModified) {
        allProject = Projects.getAllProject(filter: searchText, sortBy: sortBy, selectedProject: "")
        
        if searchText != "" {
            if allProject.count != 0 {
                resultText = "Showing results for \"\(searchText)\""
            } else {
                resultText = "No results found for \"\(searchText)\""
            }
            
        }
    }
    
    /// SEARCH BAR IN APP
    @Published var searchText = "" {
        didSet {
            if searchText != "" {
                allProject = Projects.getAllProject(filter: searchText, selectedProject: lastProject?.wrappedName)
            }
        }
    }
    
    
    
    init() {
        do {
            guard let data = UserDefaults.retrieveManagedObjectID(with: "lastProject") else {return}
            let managedObject = try DataProvider.shared.viewContext.existingObject(with: data) as? Projects
            lastProject = managedObject
        } catch {
            // Handle the error here if needed
            print("Error: \(error)")
        }
        
    }
    
    /// SELECTED FOLDER IN PANEL
    @Published var selectedProjectName: String?
    @Published var selectedProjectPhoto: Data?
    
    @Published var pinnedCollectionOnPanel: Projects? {
        didSet {
            if let pinnedCollectionOnPanel {
                selectedProjectName = pinnedCollectionOnPanel.wrappedName
                
                if let folderPhoto = pinnedCollectionOnPanel.photoArray.last,
                   let imgData = folderPhoto.photo {
                    selectedProjectPhoto = imgData
                } else {
                    selectedProjectPhoto = nil
                }
            }
        }
    }
    
    /// SAVE PROJECT
    @Published var newProject: String = ""
    
    @Published var collectionAlreadyExist = false
//    @Published 
    
    func saveProject() {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "name == %@ AND del == false", newProject
        )
        
        do {
            let test = try moc.fetch(fetchRequest)
            
            if test.count >= 1 {
                collectionAlreadyExist = true
            } else {
                let project1 = Projects(context: moc)
                
                
                if newProject != "" {
                    project1.name = newProject
                }
                
                project1.id = UUID()
                project1.dateCreated = Date.now
                project1.dateModified = Date.now
                project1.del = false
                //        project1.dateOpened = Date.now
                
                do {
                    try moc.save()
                    print("saved")
                    
                    getAllProjectinApp()
                    
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        } catch {
            print(error)
        }
        
    }
    
    func renameCollection(collectionName: String, newName: String) {

        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "name == %@ AND del == false", newName
        )
        
        do {
            let test = try moc.fetch(fetchRequest)
            
            if test.count >= 1 {
                collectionAlreadyExist = true
            } else {
                if let thisProject = Projects.getSpecificProject(filter: collectionName) {
                    thisProject.name = newName
                    thisProject.dateModified = Date.now
                }
                
                do {
                    try moc.save()
                    print("saved")
                    
                    getAllProjectinApp()
                    
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        } catch {
            print(error)
        }
        
    }
    
    func pinProject(projectName: String) {
//        lastFolder = projectName
        
        
        if projectName != "" {
//            UserDefaults.standard.set(lastFolder, forKey: "lastFolder")
            
            pinnedCollectionOnPanel = Projects.getSpecificProject(filter: projectName)
            if let pinnedCollectionOnPanel {
                UserDefaults.save(managedObjectID: pinnedCollectionOnPanel.objectID, with: "lastProject")
            }
            
        } else {
            UserDefaults.standard.removeObject(forKey: "lastProject")
//            UserDefaults.save(managedObjectID: pinnedCollectionOnPanel.objectID, with: "lastProject")
            
            pinnedCollectionOnPanel = nil
        }
        
        print(pinnedCollectionOnPanel?.name)
    }
    
//    let characterLimit = 100
    @Published var notes: String = "" 
//    {
//        didSet {
//            if notes.count > characterLimit && oldValue.count <= characterLimit {
//                notes = oldValue
//            }
//        }
//    }
    
    func addNote(photo: Photos) {
        photo.note = notes
        
        do {
            try moc.save()
            print("saved")
            
            getAllProjectinApp()
            
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
}

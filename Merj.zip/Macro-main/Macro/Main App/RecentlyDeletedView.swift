//
//  RecentlyDeletedView.swift
//  Merj
//
//  Created by Felicia Graciella on 26/11/23.
//

import SwiftUI

protocol DeletableItem {
    var objectID: NSManagedObjectID { get }
    var type: String { get }
    var deletedDate: Date? { get }
}

struct RecentlyDeletedItem: DeletableItem, Identifiable {
    let objectID: NSManagedObjectID
    let type: String
    let deletedDate: Date?
    
    // Provide a unique identifier
   var id: NSManagedObjectID {
       return objectID
   }
}

struct RecentlyDeletedView: View {
    @ObservedObject var viewModel: RootViewModel
    
    var deletedProjects: [Projects]? = Projects.getDeletedProjects()
    var deletedPhotos: [Photos]? = Photos.getDeletedPhotos()
    
    @Binding var currentSubview: AnyView
    @Binding var showingSubview: Bool
    
    @State var selectedDeletedCollection: Projects?
    @State var selectedDeletedPhoto: Photos?
    
    @State private var showingRestoreAlert = false
    @State private var showingDeleteAlert = false
    
    @State var moc = DataProvider.shared.viewContext
    
    @State var type = ""
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Recently Deleted")
                .fontWeight(.bold)
                .font(.title)
                .padding([.top, .leading])
                .frame(maxWidth: .infinity, alignment: .leading)
            
            ScrollView {
                VStack(alignment: .leading) {
                    Section {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 195, maximum: 195), spacing: 12)], alignment: .leading, spacing: 12) {
                            ForEach(deletedProjects?.prefix(6) ?? []) { collection in
                                if let managedObject = try? DataProvider.shared.viewContext.existingObject(with: collection.objectID) as? Projects {
                                    ZStack {
                                        Button(action: {
                                            selectedDeletedCollection = collection
                                            
                                            withAnimation(.easeOut(duration: 0.3)) {
                                                currentSubview = AnyView(InsideDeletedCollection(viewModel: viewModel, selectedFolder: selectedDeletedCollection, title: collection.wrappedName))
                                                showingSubview = true
                                            }
                                        }, label: {
                                            if(managedObject.photoArray.count != 0) {
                                                ZStack {
                                                    FolderThumbnail(image: NSImage(data: managedObject.photoArray[(managedObject.photoArray.count )-1].photo ?? Data())!, title: managedObject.wrappedName)
                                                }

                                            } else {
                                                ZStack {
                                                    FolderThumbnail(image: nil, title: managedObject.wrappedName)
                                                }

                                            }
                                        })
                                        .buttonStyle(PlainButtonStyle())
                                        
                                        VStack {
                                            HStack {
                                                Spacer()
        
                                                /// MAKE REUSABLE COMPONENT
                                                EllipsesMenu(button1Name: "Recover", button2Name: "Delete Permanently") {
                                                    selectedDeletedCollection = collection
                                                    type = "Collection"
                                                    showingRestoreAlert = true
                                                } button2OnClick: {
                                                    selectedDeletedCollection = collection
                                                    type = "Collection"
                                                    showingDeleteAlert = true
                                                }
                                            }
                                            .frame(width: 200)
        
                                            Spacer()
                                        }
                                    }
                                    
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .topLeading)
                    } header: {
                        HStack {
                            Text("Recently Deleted Collection")
//                                .font(.title3)
                            
                            Spacer()
                            
                            Button("See All") {
                                withAnimation(.easeOut(duration: 0.3)) {
                                    currentSubview = AnyView(RecentlyDeletedCollectionView(viewModel: viewModel, currentSubview: $currentSubview, showingSubview: $showingSubview))
                                    showingSubview = true
                                }
                                
                            }
                            .foregroundStyle(.blue)
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                    
                    Section {
                        VMasonry(columns: .adaptive(sizeConstraint: .min(200)), spacing: 0) {
                            
                            ForEach(deletedPhotos ?? []) { photo in
                                if let managedObject = try? DataProvider.shared.viewContext.existingObject(with: photo.objectID) as? Photos {
                                    
                                    VStack{
                                        let image = NSImage(data: managedObject.photo ?? Data()) ?? NSImage()
                                        
                                        ZStack {
                                            Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                                                .cornerRadius(4)
                                                .overlay( /// apply a rounded border
                                                    RoundedRectangle(cornerRadius: 4)
                                                        .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                                                )
                                            
                                            VStack {
                                                Image(nsImage: image)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .clipShape(Rectangle())
                                                    .cornerRadius(4)
                                                    .shadow(color: Color(#colorLiteral(red: 0.3491805792, green: 0.358153522, blue: 0.3706106544, alpha: 0.3)), radius: 2, x: 2, y: 2)
                                                
                                                if managedObject.note != "" {
                                                    HStack {
                                                        Text("\(managedObject.note ?? "")")
                                                            .lineLimit(2)
                                                        
                                                        Spacer()
                                                        
                                                    }
                                                    .padding([.bottom, .horizontal], 4)
                                                }
                                            }
                                            
                                            VStack {
                                                HStack {
                                                    Spacer()
            
                                                    /// MAKE REUSABLE COMPONENT
                                                    EllipsesMenu(button1Name: "Restore", button2Name: "Delete Permanently") {
                                                        selectedDeletedPhoto = managedObject
                                                        type = "Image"
                                                        showingRestoreAlert = true
                                                    } button2OnClick: {
                                                        selectedDeletedPhoto = managedObject
                                                        type = "Image"
                                                        showingDeleteAlert = true
                                                    }
                                                }
            
                                                Spacer()
                                            }
                                        }
                                        .padding([.trailing, .bottom])
                                        .cornerRadius(4)
                                        
                                    }
                                }
                            }
                        }
                    } header: {
                        Text("Recently Deleted Images")
//                            .font(.title3)
                            .padding(.top)
                    }
                    .padding(.leading)
                
                }
                
                
            }
        }
        .alert(
            "Restore \(type)?",
            isPresented: $showingRestoreAlert
        ) {
            Button("Restore", role: .destructive) {
                withAnimation {
                    if type == "Collection" {
                        let fetchRequest: NSFetchRequest<Projects>
                        fetchRequest = Projects.fetchRequest()

                        fetchRequest.predicate = NSPredicate(
                            format: "name == %@ AND del == false", selectedDeletedCollection?.name ?? ""
                        )
                        
                        do {
                            let test = try moc.fetch(fetchRequest)
                            
                            if test.count >= 1 {
                                selectedDeletedCollection?.name = (selectedDeletedCollection?.name ?? "") + "(2)"
                                
                                selectedDeletedCollection?.del = false
                                selectedDeletedCollection?.dateDeleted = nil
                                
                                
                                do {
                                    try moc.save()
                                    print("restore \(selectedDeletedCollection?.wrappedName)")
                                    
                                } catch let error as NSError {
                                    print("Could not save. \(error), \(error.userInfo)")
                                }
                                
                                showingRestoreAlert = false
                                
                                viewModel.getAllProjectinApp()
                            } else {
                                selectedDeletedCollection?.del = false
                                selectedDeletedCollection?.dateDeleted = nil
                                
                                
                                do {
                                    try moc.save()
                                    print("restore \(selectedDeletedCollection?.wrappedName)")
                                    
                                } catch let error as NSError {
                                    print("Could not save. \(error), \(error.userInfo)")
                                }
                                
                                showingRestoreAlert = false
                                
                                viewModel.getAllProjectinApp()
                            }
                        } catch {
                            print("error")
                        }
                    
                        
                    } else {
                        selectedDeletedPhoto?.del = false
                        selectedDeletedPhoto?.dateDeleted = nil
                        
                        
                        do {
                            try moc.save()
                            print("restored image")
                            
                        } catch let error as NSError {
                            print("Could not save. \(error), \(error.userInfo)")
                        }
                        
                        showingRestoreAlert = false
                        
                        viewModel.getAllProjectinApp()
                    }
                    
                    
                }
            }
        }
        .alert(
            "Delete \(type) Permanently?",
            isPresented: $showingDeleteAlert
        ) {
            Button("Delete", role: .destructive) {
                withAnimation {
                    if type == "Collection" {
                        if let deleteCollection = selectedDeletedCollection {
                            do {
                                
                                try moc.delete(deleteCollection)
                                
                            } catch let error as NSError {
                                print("Could not save. \(error), \(error.userInfo)")
                            }
                            
                            showingDeleteAlert = false
                            
                            viewModel.getAllProjectinApp()
                        }
                    } else {
                        if let deletePhoto = selectedDeletedPhoto {
                            do {
                                
                                try moc.delete(deletePhoto)
                                
                            } catch let error as NSError {
                                print("Could not save. \(error), \(error.userInfo)")
                            }
                            
                            showingDeleteAlert = false
                            
                            viewModel.getAllProjectinApp()
                        }
                    }
                    
                    
                    
                    
                }
            }
        }
    }
}

//#Preview {
//    RecentlyDeletedView()
//}

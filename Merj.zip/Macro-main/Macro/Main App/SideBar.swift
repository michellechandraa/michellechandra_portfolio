//
//  SideBar.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct SideBar: View {
    @EnvironmentObject private var appState: AppState
    @State var clickStatus: Bool = true
    @State var clickStatus2: Bool = false
    
    
    var body: some View {
        List {
            HStack{
                Image(systemName: "rectangle.on.rectangle.angled")
                    .frame(width: 12)
                Text("All Collections")
            }
            .foregroundStyle(clickStatus ? .white : .primary)
            .listRowBackground(clickStatus ? Color.strongOrange.clipShape(RoundedRectangle(cornerRadius: 6)).padding(.horizontal, 10) : Color.clear.clipShape(RoundedRectangle(cornerRadius: 6)).padding(.horizontal))
            .onTapGesture {
                withAnimation(.easeOut(duration: 0.3)) {
                    appState.routes.removeAll()
                    appState.push(.allProjects)
                    clickStatus = true
                    clickStatus2 = false
                }
            }
            
            HStack{
                Image(systemName: "trash")
                    .frame(width: 12)
                Text("Recently Deleted")
            }
            .foregroundStyle(clickStatus2 ? .white : .primary)
            .listRowBackground(clickStatus2 ? Color.strongOrange.clipShape(RoundedRectangle(cornerRadius: 6)).padding(.horizontal, 10) : Color.clear.clipShape(RoundedRectangle(cornerRadius: 6)).padding(.horizontal))
            .onTapGesture {
                withAnimation(.easeOut(duration: 0.3)) {
                    appState.routes.removeAll()
                    appState.push(.recentlyDeleted)
                    clickStatus = false
                    clickStatus2 = true
                }
                
            }
            
        }
        
    }
    
}

//struct SideBar_Previews: PreviewProvider {
//    static var previews: some View {
//        SideBar()
//    }
//}

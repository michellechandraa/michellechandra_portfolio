//
//  InsideFolderView.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct InsideFolderView: View {
    @ObservedObject var viewModel: RootViewModel
//    @EnvironmentObject var appState: AppState
    
    @Environment(\.openURL) var openURL
    @State var showViewImage: Bool = false
    @State var currentIndex: Int = 0
//    @State private var totalHeight: CGFloat = 0
    @State private var printButtonClicked: Bool = false
    @State var  miSize : CGSize = .zero
    var selectedFolder: Projects!
    
    @Binding var currentSubview: AnyView
    @Binding var showingSubview: Bool
    
    var title: String
    
    @State var addNotes = false
    
    @State var selectedPhoto: Photos?
    
    @State private var showingDeleteAlert = false
    
    @State var moc = DataProvider.shared.viewContext
    
    @FocusState var textFieldIsFocused: Bool
    
    var body: some View {
        
        VStack{
            HStack{
                Text(title)
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .bottomLeading)
                    .padding([.top, .leading])
                Spacer()
                
                //Print Button
                Button(action: {
                    printButtonClicked.toggle()
                    currentSubview = AnyView(PrintView(selectedFolder: selectedFolder, viewModel: viewModel, title: title, currentSubview: $currentSubview, showingSubview: $showingSubview))
                    showingSubview = true
                }) {
                    Text("Print")
                }
                .padding(.trailing)
                .padding(.top, 12)
            }
            
            if selectedFolder.photoArray.count != 0{
                            ScrollView(.vertical) {
                                VMasonry(columns: .adaptive(sizeConstraint: .min(200)), spacing: 0) {
                                    
                                    ForEach(Array(selectedFolder.photoArray.enumerated().reversed()), id: \.1) { index, photo in
                                        if photo.del != true {
                                            VStack{
                                                let image = NSImage(data: photo.photo ?? Data()) ?? NSImage()
                                                
                                                ZStack {
                                                    Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                                                        .cornerRadius(4)
                                                        .overlay( /// apply a rounded border
                                                            RoundedRectangle(cornerRadius: 4)
                                                                .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                                                        )
                                                    
                                                    VStack {
                                                        Image(nsImage: image)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .clipShape(Rectangle())
                                                            .cornerRadius(4)
                                                            .shadow(color: Color(#colorLiteral(red: 0.3491805792, green: 0.358153522, blue: 0.3706106544, alpha: 0.3)), radius: 2, x: 2, y: 2)
                                                            .onDrag {
                                                                guard let tiffRepresentation = image.tiffRepresentation,
                                                                      let bitmapImage = NSBitmapImageRep(data: tiffRepresentation),
                                                                      let bitmapRepresentation = bitmapImage.representation(using: .png, properties: [:]) else {
                                                                    
                                                                    return NSItemProvider(item: image.tiffRepresentation as NSSecureCoding?, typeIdentifier: kUTTypeTIFF as String)
                                                                }
                                                                
                                                                let url = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("dragExport.png")
                                                                try! bitmapRepresentation.write(to: url)
                                                                
                                                                let provider = NSItemProvider(item: url as NSSecureCoding?, typeIdentifier: kUTTypeFileURL as String)
                                                                provider.suggestedName = url.lastPathComponent
                                                                
                                                                return provider
                                                            }
                                                            .onTapGesture{
                                                                showViewImage.toggle()
                                                                currentIndex = index
                                                            }
                                                        
                                                            
                                                        if photo.note == "" && addNotes == true && selectedPhoto == photo {
                                                            HStack {
                                                                TextField("Add note", text: $viewModel.notes, axis: .vertical)
                                                                    .onChange(of: viewModel.notes) { newValue in
                                                                        if viewModel.notes.count > 100 {
                                                                            viewModel.notes = String(viewModel.notes.prefix(100))
                                                                        }
                                                                    }
                                                                    .onSubmit {
                                                                        withAnimation(.easeOut(duration: 0.3)) {
                                                                            viewModel.addNote(photo: photo)
                                                                            
                                                                            viewModel.notes = ""
                                                                            addNotes = false
                                                                        }
                                                                    }
                                                                    .textFieldStyle(.plain)
                                                                    .focused($textFieldIsFocused)
                                                                
                                                                Spacer()
                                                                
                                                                VStack(alignment: .trailing) {
                                                                    Button {
                                                                        withAnimation(.easeOut(duration: 0.3)) {
                                                                            addNotes.toggle()
                                                                        }
                                                                    } label: {
                                                                        ZStack {
                                                                            Rectangle()
                                                                                .fill(.white)
                                                                                .opacity(0.1)
                                                                                .cornerRadius(4)
                                                                                
                                                                            Image(systemName: "x.circle")
                                                                                .padding(4)
                                                                        }
                                                                        
                                                                    }
                                                                    .frame(width: 15)
                                                                    .buttonStyle(.plain)
                                                                    .padding(.horizontal, 4)
                                                                    
                                                                    Spacer()
                                                                    
                                                                    Text("\(viewModel.notes.count)/100")
                                                                        .font(.system(size: 8))
                                                                }
                                                            }
                                                            .padding([.bottom, .horizontal], 4)
                                                            
                                                        } else if photo.note != "" && addNotes == true && selectedPhoto == photo{
                                                            HStack {
                                                                TextField("Edit note", text: $viewModel.notes, axis: .vertical)
                                                                    .onChange(of: viewModel.notes) { newValue in
                                                                        if viewModel.notes.count > 100 {
                                                                            viewModel.notes = String(viewModel.notes.prefix(100))
                                                                        }
                                                                    }
                                                                    .onSubmit {
                                                                        withAnimation(.smooth(duration: 0.3)) {
                                                                            viewModel.addNote(photo: photo)
                                                                            
                                                                            viewModel.notes = ""
                                                                            addNotes = false
                                                                        }
                                                                    }
                                                                    .textFieldStyle(.plain)
                                                                    .focused($textFieldIsFocused)
            //                                                        .padding()
                                                                
                                                                Spacer()
                                                                
                                                                VStack(alignment: .trailing) {
                                                                    Button {
                                                                        withAnimation(.easeOut(duration: 0.3)) {
                                                                            addNotes.toggle()
                                                                        }
                                                                    } label: {
                                                                        ZStack {
                                                                            Rectangle()
                                                                                .fill(.white)
                                                                                .opacity(0.1)
                                                                                .cornerRadius(4)
                                                                                
                                                                            Image(systemName: "x.circle")
                                                                                .padding(4)
                                                                        }
                                                                        
                                                                    }
                                                                    .frame(width: 15)
                                                                    .buttonStyle(.plain)
                                                                    .padding(.horizontal, 4)
                                                                    
                                                                    Spacer()
                                                                    
                                                                    Text("\(viewModel.notes.count)/100")
                                                                        .font(.system(size: 8))
                                                                }
                                                            }
                                                            .padding([.bottom, .horizontal], 4)
                                                        } else if photo.note != "" && photo.note != nil {
                                                            HStack {
                                                                Text("\(photo.note ?? "")")
                                                                    .lineLimit(2)
                                                                
                                                                Spacer()
                                                                    
                                                                VStack(alignment: .trailing) {
                                                                    Button {
                                                                        withAnimation(.easeOut(duration: 0.3)) {
                                                                            selectedPhoto = photo
                                                                            addNotes = true
                                                                            viewModel.notes = photo.note ?? ""
                                                                            textFieldIsFocused = true
                                                                        }
                                                                    } label: {
                                                                        ZStack {
                                                                            Rectangle()
                                                                                .fill(.white)
                                                                                .opacity(0.1)
                                                                                .cornerRadius(4)
                                                                                
                                                                            Image(systemName: "pencil")
                                                                                .padding(4)
                                                                        }
                                                                        
                                                                    }
                                                                    
                                                                    .frame(width: 15)
                                                                    .buttonStyle(.plain)
                                                                    .padding(.horizontal, 4)
                                                                    
                                                                    Spacer()
                                                                    
                                                                    Text("\(photo.note?.count ?? 0)/100")
                                                                        .font(.system(size: 8))
                                                                }
                                                            }
                                                            .padding([.bottom, .horizontal], 4)
                                                        }
                                                    }
                                                    
                                                    VStack {
                                                        HStack {
                                                            Spacer()
                                                            
                                                            EllipsesMenu(button1Name: photo.note == "" ? "Add note" : "Edit note", button2Name: "Delete") {
                                                                if photo.note == "" {
                                                                    withAnimation(.easeIn(duration: 0.3)) {
                                                                        print("new note")
                                                                        addNotes = true
                                                                        
                                                                        selectedPhoto = photo
                                                                        viewModel.notes = ""
                                                                        
                                                                        textFieldIsFocused = true
                                                                    }
                                                                } else {
                                                                    withAnimation(.easeOut(duration: 0.3)) {
                                                                        selectedPhoto = photo
                                                                        addNotes = true
                                                                        viewModel.notes = photo.note ?? ""
                                                                        
                                                                        textFieldIsFocused = true
                                                                    }
                                                                }
                                                            } button2OnClick: {
                                                                currentIndex = index
                                                                showingDeleteAlert = true
                                                            }
                                                           
                                                            
                                                        }
                                                        
                                                        Spacer()
                                                    }
                                                }
                                                .padding(.trailing)
                                                .cornerRadius(4)
                                                
                                            
                                                
                                                HStack{
                                                    if photo.link != nil {
                                                        Button {
                                                            openURL(URL(string: photo.link ?? "https://www.google.com/")!)
                                                        } label: {
                                                            HStack {
                                                                Image(systemName: "arrow.up.right")
                                                                
                                                                Text("Go to source")
                                                            }
                                                            .background(.clear)
                                                            .foregroundColor(Color("StrongOrange"))
                                                            
                                                        }
                                                        .buttonStyle(.plain)
                                                    }
                                                    else {
                                                        Text ("No link attached.")
                                                            .foregroundColor(.gray)
                                                            .font(.system(size: 13))
                                                    }
                                                    
                                                    Spacer()
                                                }
                                                .padding([.trailing, .bottom])
                                            }
                                            
                                        }
                                        
                                    }
                                }
                                .padding(.leading)
                                
                            }
                            .onChange(of: selectedFolder.photoArray.count) { _, _ in
                                viewModel.getAllProjectinApp()
                            }
                            .sheet(isPresented: $showViewImage, content: {
                                ViewImage(
                                    viewModel: viewModel,
                                    currentImageIndex: $currentIndex,
                                    showViewImage: $showViewImage,
                                    selectedFolder:selectedFolder,
                                    title: title
                                )
                            })
                        } else {
                            Text("Start dropping images in the floating panel")
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        }
                
            
        }
        
        .alert(
            "Delete from \(title)?",
            isPresented: $showingDeleteAlert
        ) {
            Button("Delete", role: .destructive) {
                withAnimation {
                    do {
                        if let managedObject = try DataProvider.shared.viewContext.existingObject(with: selectedFolder.photoArray[currentIndex].objectID) as! Photos? {
                            
                            selectedPhoto = managedObject
                        }
                    } catch {
                        print(error)
                    }
                    
                    selectedPhoto?.del = true
                    selectedPhoto?.dateDeleted = Date.now
                    
                    do {
                        try moc.save()
                        print("saved")
                        
                    } catch let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                    }
                    
                    
                    showingDeleteAlert = false
                    
                    viewModel.getAllProjectinApp()
                }
            }
        }
        
        .navigationTitle("All Collections")
    }
}

struct ViewGeometryMi: View {
    var body: some View {
            GeometryReader { geometry in
                Color.clear
                    .preference(key: ViewHeightKeyMi.self, value: geometry.size)
            }
    }
}

struct ViewHeightKeyMi: PreferenceKey {
    static var defaultValue: CGSize = .zero
    
    static func reduce(value: inout CGSize, nextValue: () -> CGSize) {
        value.width += nextValue().width
        value.height += nextValue().width
    }
}

struct SizeCalculator: ViewModifier {
    
    @Binding var size: CGSize
    
    func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { proxy in
                    Color.clear // we just want the reader to get triggered, so let's use an empty color
                        .onAppear {
                            size = proxy.size
                        }
                }
            )
    }
}

extension View {
    func saveSize(in size: Binding<CGSize>) -> some View {
        modifier(SizeCalculator(size: size))
    }
}

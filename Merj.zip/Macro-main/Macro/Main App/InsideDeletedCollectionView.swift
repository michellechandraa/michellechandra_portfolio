//
//  InsideDeletedCollection.swift
//  Merj
//
//  Created by Felicia Graciella on 29/11/23.
//

import SwiftUI

struct InsideDeletedCollection: View {
    @ObservedObject var viewModel: RootViewModel
//    @EnvironmentObject var appState: AppState
    
    @Environment(\.openURL) var openURL
    @State var showViewImage: Bool = false
    @State var currentIndex: Int = 0
    
    var selectedFolder: Projects!
    
    var title: String
    
    @State var addNotes = false
    
    @State var selectedPhoto: Photos?
    
    @State private var showingDeleteAlert = false
    
    @State var moc = DataProvider.shared.viewContext
    
    var body: some View {
        VStack{
            HStack{
                Text(title)
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .bottomLeading)
                    .padding([.top, .leading])
                Spacer()
            }
            
            
            if selectedFolder.photoArray.count != 0{
                ScrollView(.vertical) {
                    VMasonry(columns: .adaptive(sizeConstraint: .min(200)), spacing: 0) {
                        
                        ForEach(Array(selectedFolder.photoArray.enumerated().reversed()), id: \.1) { index, photo in
                            if photo.del != true {
                                VStack{
                                    let image = NSImage(data: photo.photo ?? Data()) ?? NSImage()
                                    
                                    ZStack {
                                        Color(#colorLiteral(red: 0.850980401, green: 0.850980401, blue: 0.850980401, alpha: 0.4))
                                            .cornerRadius(4)
                                            .overlay( /// apply a rounded border
                                                RoundedRectangle(cornerRadius: 4)
                                                    .stroke(Color(#colorLiteral(red: 0.6705882549, green: 0.6705882549, blue: 0.6705882549, alpha: 0.3)), lineWidth: 1)
                                            )
                                        
                                        VStack {
                                            Image(nsImage: image)
                                                .resizable()
                                                .scaledToFill()
                                                .clipShape(Rectangle())
                                                .cornerRadius(4)
                                                .shadow(color: Color(#colorLiteral(red: 0.3491805792, green: 0.358153522, blue: 0.3706106544, alpha: 0.3)), radius: 2, x: 2, y: 2)
                                            
                                                
                                            if photo.note != "" {
                                                HStack {
                                                    Text("\(photo.note ?? "")")
                                                        .lineLimit(2)
                                                    
                                                    Spacer()
                                                    
                                                }
                                                .padding([.bottom, .horizontal], 4)
                                            }
                                        }
                                    }
                                    .padding([.trailing, .bottom])
                                    .cornerRadius(4)
                                }
                                
                            }
                            
                        }
                    }
                    .padding(.leading)
                    
                }
                .onChange(of: selectedFolder.photoArray.count) { _, _ in
                    viewModel.getAllProjectinApp()
                }
                .sheet(isPresented: $showViewImage, content: {
                    ViewImage(
                        viewModel: viewModel,
                        currentImageIndex: $currentIndex,
                        showViewImage: $showViewImage,
                        selectedFolder:selectedFolder,
                        title: title
                    )
                })
            } else {
                Text("Empty Collection")
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            }
            
        }
        
        .navigationTitle("Recently Deleted")
    }
}

//#Preview {
//    InsideDeletedCollection()
//}

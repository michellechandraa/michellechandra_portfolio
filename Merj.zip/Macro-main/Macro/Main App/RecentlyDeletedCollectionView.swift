//
//  RecentlyAddedView.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct RecentlyDeletedCollectionView: View {
    
    @ObservedObject var viewModel: RootViewModel
    
    var deletedProjects: [Projects]? = Projects.getDeletedProjects()
    
    @Binding var currentSubview: AnyView
    @Binding var showingSubview: Bool
    
    @State var selectedDeletedCollection: Projects?
    
    @State private var showingRestoreAlert = false
    @State private var showingDeleteAlert = false
    
    @State var moc = DataProvider.shared.viewContext
    
    var body: some View {
        VStack {
            Text("Recently Deleted Collection")
                .fontWeight(.bold)
                .font(.title)
                .padding(.leading)
                .padding(.top, 12)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 200, maximum: 200), spacing: 16)], alignment: .leading, spacing: 16) {
                    ForEach(deletedProjects ?? []) { collection in
                        if let managedObject = try? DataProvider.shared.viewContext.existingObject(with: collection.objectID) as? Projects {
                            Button(action: {
                                selectedDeletedCollection = collection
                                
                                withAnimation(.easeOut(duration: 0.3)) {
                                    currentSubview = AnyView(InsideDeletedCollection(viewModel: viewModel, selectedFolder: selectedDeletedCollection, title: collection.wrappedName))
                                    showingSubview = true
                                }
                            }, label: {
                                if(managedObject.photoArray.count != 0) {
                                    ZStack {
                                        FolderThumbnail(image: NSImage(data: managedObject.photoArray[(managedObject.photoArray.count )-1].photo ?? Data())!, title: managedObject.wrappedName)
                                        
                                        VStack {
                                            HStack {
                                                Spacer()
        
                                                /// MAKE REUSABLE COMPONENT
                                                EllipsesMenu(button1Name: "Recover", button2Name: "Delete Permanently") {
                                                    selectedDeletedCollection = collection
                                                    showingRestoreAlert = true
                                                } button2OnClick: {
                                                    selectedDeletedCollection = collection
                                                    showingDeleteAlert = true
                                                }
                                            }
                                            .frame(width: 200)
        
                                            Spacer()
                                        }
                                    }

                                } else {
                                    ZStack {
                                        FolderThumbnail(image: nil, title: managedObject.wrappedName)
                                        
                                        VStack {
                                            HStack {
                                                Spacer()
        
                                                /// MAKE REUSABLE COMPONENT
                                                EllipsesMenu(button1Name: "Recover", button2Name: "Delete Permanently") {
                                                    selectedDeletedCollection = collection
                                                    showingRestoreAlert = true
                                                } button2OnClick: {
                                                    selectedDeletedCollection = collection
                                                    showingDeleteAlert = true
                                                }
                                            }
                                            .frame(width: 200)
        
                                            Spacer()
                                        }
                                    }

                                }
                            })
                            .buttonStyle(PlainButtonStyle())
    //                                .padding(.trailing, 10)
                        }
                    }
                }
                .padding(.horizontal)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            }
            
        }
        .alert(
            "Restore Collection?",
            isPresented: $showingRestoreAlert
        ) {
            Button("Restore", role: .destructive) {
                withAnimation {
                    let fetchRequest: NSFetchRequest<Projects>
                    fetchRequest = Projects.fetchRequest()

                    fetchRequest.predicate = NSPredicate(
                        format: "name == %@ AND del == false", selectedDeletedCollection?.name ?? ""
                    )
                    
                    do {
                        let test = try moc.fetch(fetchRequest)
                        
                        if test.count >= 1 {
                            selectedDeletedCollection?.name = (selectedDeletedCollection?.name ?? "") + "(2)"
                            
                            selectedDeletedCollection?.del = false
                            selectedDeletedCollection?.dateDeleted = nil
                            
                            
                            do {
                                try moc.save()
                                print("restore \(selectedDeletedCollection?.wrappedName)")
                                
                            } catch let error as NSError {
                                print("Could not save. \(error), \(error.userInfo)")
                            }
                            
                            showingRestoreAlert = false
                            
                            viewModel.getAllProjectinApp()
                        } else {
                            selectedDeletedCollection?.del = false
                            selectedDeletedCollection?.dateDeleted = nil
                            
                            
                            do {
                                try moc.save()
                                print("restore \(selectedDeletedCollection?.wrappedName)")
                                
                            } catch let error as NSError {
                                print("Could not save. \(error), \(error.userInfo)")
                            }
                            
                            showingRestoreAlert = false
                            
                            viewModel.getAllProjectinApp()
                        }
                    } catch {
                        print("error")
                    }
                }
            }
        }
        .alert(
            "Delete Collection Permanently?",
            isPresented: $showingDeleteAlert
        ) {
            Button("Delete", role: .destructive) {
                withAnimation {
                    if let deleteCollection = selectedDeletedCollection {
                        do {
                            
                            try moc.delete(deleteCollection)
                            
                        } catch let error as NSError {
                            print("Could not save. \(error), \(error.userInfo)")
                        }
                        
                        showingDeleteAlert = false
                        
                        viewModel.getAllProjectinApp()
                    }
                }
            }
        }
    }
}

//struct RecentlyDeletedCollectionView_Previews: PreviewProvider {
//    static var previews: some View {
//        RecentlyDeletedCollectionView()
//    }
//}

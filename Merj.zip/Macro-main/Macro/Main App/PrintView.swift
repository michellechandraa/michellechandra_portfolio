//
//  PrintvIEW.swift
//  Merj
//
//  Created by michelle chandra on 28/11/23.
//

import SwiftUI

struct PrintView: View {
    @State private var printButtonClicked: Bool = false
    var selectedFolder: Projects!
    @Environment(\.openURL) var openURL
    @State var showViewImage: Bool = false
    @State var currentIndex: Int = 0
    @State private var totalHeight: CGFloat = 0
    @ObservedObject var viewModel: RootViewModel
    @State var  miSize : CGSize = .zero
    
    @State var runPrint = false

    var title: String
    
    @Binding var currentSubview: AnyView
    @Binding var showingSubview: Bool
    
    var body: some View {
        ScrollView{
            VMasonry(columns: .fixed(2) , spacing: 12) {
                ForEach(Array(selectedFolder.photoArray.enumerated().reversed()), id: \.1) { index, photo in
                    if photo.del != true {
                        VStack{
                            let image = NSImage(data: photo.photo ?? Data()) ?? NSImage()
                            
                            Image(nsImage: image)
                                .resizable()
                                .scaledToFit()
                                .clipShape(Rectangle())
                                .cornerRadius(4)
                                .shadow(color: Color(#colorLiteral(red: 0.3491805792, green: 0.358153522, blue: 0.3706106544, alpha: 0.3)), radius: 2, x: 2, y: 2)
                        }
                        .onTapGesture{
                            showViewImage.toggle()
                            currentIndex = index
                        }
                    }
                }
            }
            .background(ViewGeometryMi())
            .onPreferenceChange(ViewHeightKeyMi.self) {
                    miSize = $0
                    print("Haha:",miSize)
            }
            .onChange(of: selectedFolder.photoArray.count) { _, _ in
                viewModel.getAllProjectinApp()
            }
            .onAppear(perform: {
                if !runPrint {
                    runPrint = true
                    guard let window = NSApplication.shared.mainWindow else { return }
                    
                    window.setFrame(.init(origin: CGPoint(x: window.frame.minX, y: window.frame.minY), size: CGSize(width: 600, height: window.frame.height)), display: true, animate: true)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now()){
                        let pi = NSPrintInfo.shared
                        pi.topMargin = 0.0
                        pi.bottomMargin = 0.0
                        pi.leftMargin = 0.0
                        pi.rightMargin = 0.0
                        pi.orientation = .portrait
                        pi.isHorizontallyCentered = false
                        pi.isVerticallyCentered = false
                        pi.scalingFactor = 1.0
                        
                        let rootView = self
                        let view = NSHostingView(rootView: rootView)
                        
                        print(view.frame.height)
                        print("MiSize width:", miSize.width)
                        print("MiSize height:", miSize.height)
                        let myImageWidth = miSize.width
                        let myImageHeight = miSize.height
                        let myViewWidth:CGFloat = 550
                        
                        let ratio = myViewWidth/myImageWidth

                        let contentRect = NSRect(x: 0, y: 0, width: miSize.width, height: miSize.height)
                        
                        view.frame.size = contentRect.size
                        
                        let contentRect2 = NSRect(x: 0, y: 0, width: myViewWidth, height: miSize.height * ratio)
                        let myNSBitMapRep = view.bitmapImageRepForCachingDisplay(in: contentRect)!
                        view.cacheDisplay(in: view.frame, to: myNSBitMapRep)
                        
                        let myNSImage = NSImage(size: contentRect2.size)
                        myNSImage.addRepresentation(myNSBitMapRep)
                        
                        let nsImageView = NSImageView(frame: contentRect2)
                        nsImageView.image = myNSImage
                        
                        let po = NSPrintOperation(view: nsImageView, printInfo: pi)
                        
                        po.printInfo.orientation = .portrait
                        po.showsPrintPanel = true
                        po.showsProgressPanel = true
                        
                        po.printPanel.options.insert(NSPrintPanel.Options.showsPaperSize)
                        po.printPanel.options.insert(NSPrintPanel.Options.showsOrientation)
                        
                        if po.run() {
                            print("In Print completion")
                        }
                        printButtonClicked.toggle()
                    }
                } else {
                    // go back to inside folder view
                    currentSubview = AnyView(InsideFolderView(viewModel: viewModel, selectedFolder: selectedFolder, currentSubview: $currentSubview, showingSubview: $showingSubview, title: title))
                }
            })
        }
    }
}

//#Preview {
//    PrintView(viewModel: RootViewModel(), title: )
//}

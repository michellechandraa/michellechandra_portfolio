//
//  FolderThumbnail.swift
//  MerjUI
//
//  Created by Evelyn Megawati Tiffany on 17/10/23.
//

import SwiftUI

struct FolderThumbnail: View {
    var image: NSImage?
    var title: String
    
    var selectedFolder: Projects!
    
    var body: some View {
        ZStack{
            if let image {
                Image(nsImage : image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 195, height: 195)
            } else {
                Rectangle()
                    .foregroundStyle(Color("LilDarkGray"))
            }
        
            
            VStack {
                Spacer()
                
                ZStack{
                    VisualEffectView(material: .hudWindow, blendingMode: .withinWindow)
                        .frame(width: 195, height: 70)
                    
                    Text(title)
                        .fixedSize(horizontal: false, vertical: true)
                        .font(.title3)
                        .padding()
                        .frame(width: 190, height: 65, alignment: .leading)
                        .lineLimit(2)
                    
                }
                .clipShape(Rectangle())
                .cornerRadius(8)
            }
            
            
        }
        .frame(width: 195, height: 195)
        .clipShape(Rectangle())
        .cornerRadius(10)
        .shadow(color: Color(#colorLiteral(red: 0.3491805792, green: 0.358153522, blue: 0.3706106544, alpha: 0.3)), radius: 2, x: 2, y: 2)
        
    }
}

struct FolderThumbnail_Previews: PreviewProvider {
    static var previews: some View {
        FolderThumbnail(image: NSImage(), title: "Folder")
    }
}

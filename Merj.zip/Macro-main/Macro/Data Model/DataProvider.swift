//
//  DataProvider.swift
//  Macro
//
//  Created by Felicia Graciella on 11/10/23.
//

import Foundation
import CoreData

final class DataProvider {
    static let shared = DataProvider()
    
    private let persistentContainer : NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        persistentContainer.viewContext
    }
    
    private init() {
        persistentContainer = NSPersistentContainer(name: "MerjData")
        persistentContainer.viewContext.automaticallyMergesChangesFromParent = true
        persistentContainer.loadPersistentStores { _, error in
            if let error {
                fatalError("Unable to load store with error: \(error)")
            }
        }
    }
}

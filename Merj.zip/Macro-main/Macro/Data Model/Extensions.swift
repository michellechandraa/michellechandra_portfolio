//
//  Extensions.swift
//  Macro
//
//  Created by Felicia Graciella on 10/11/23.
//

import Foundation
import CoreData

extension UserDefaults {
    
    static func save(managedObjectID: NSManagedObjectID, with keyName: String) {
        
        let uriString = managedObjectID.uriRepresentation().absoluteString
        
        UserDefaults.standard.set(uriString, forKey: keyName)
    }

    static func retrieveManagedObjectID(viewContext: NSManagedObjectContext = DataProvider.shared.viewContext,
                                 with keyName: String) -> NSManagedObjectID? {
        
        if let uriString = UserDefaults.standard.string(forKey: keyName),
           let url = URL(string: uriString),
           let coordinator = viewContext.persistentStoreCoordinator,
           let managedObjectID = coordinator.managedObjectID(forURIRepresentation: url) {
            
            return managedObjectID
            
        }
        return nil
    }
}

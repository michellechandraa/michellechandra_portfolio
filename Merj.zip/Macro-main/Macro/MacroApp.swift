//
//  MacroApp.swift
//  Macro
//
//  Created by michelle chandra on 06/10/23.
//

import SwiftUI
//import SwiftData

@main
struct MacroApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @ObservedObject var panelVM: FloatingPanelViewModel = FloatingPanelViewModel()
    
    @State private var currentSubview = AnyView(ContentView())
    @State private var fromPanel = false
    
    @State var isPopoverPartFour: Bool = false
    
    init() {
        currentSubview = AnyView(InsideFolderView(viewModel: RootViewModel(), selectedFolder: panelVM.lastProject, currentSubview: $currentSubview, showingSubview: $showingSubview, title: panelVM.lastProject?.wrappedName ?? ""))
    }
    
    @State private var showingSubview = true
    
    var body: some Scene {
        WindowGroup(id: "Main App") {
            let window = NSScreen.main?.visibleFrame
            
            RootView(isPopoverPartFour: $isPopoverPartFour, isPopoverPartFive: .constant(false), viewModel: RootViewModel())
                .frame(minWidth: window!.width/5,
                       idealWidth: window!.width,
                       maxWidth: window!.width,
                       minHeight: window!.height/2.8,
                       idealHeight: window!.height,
                       maxHeight: window!.height)
                .environment(\.managedObjectContext, DataProvider.shared.viewContext)
                .environmentObject(AppState())
                .onAppear{
                    if UserDefaults.standard.integer(forKey: "onboardingStatus") == 3 {
                        isPopoverPartFour = true
                    } else {
                        isPopoverPartFour = false
                    }
                }
            
//            RecentlyDeletedView()
        }
        .windowResizability(.automatic)
    }
}

class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {

    var newEntryPanel: FloatingPanelSettings<FloatingPanelView>!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        if let window = NSApplication.shared.windows.first {
            window.close()
        }

        
        newEntryPanel = FloatingPanelSettings(view: FloatingPanelView())
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
}

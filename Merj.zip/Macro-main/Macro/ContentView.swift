//
//  ContentView.swift
//  Macro
//
//  Created by michelle chandra on 06/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RootView(isPopoverPartFour: .constant(false), isPopoverPartFive: .constant(false))
    }
}

#Preview {
    ContentView()
}

//
//  FloatingPanelAddFolder.swift
//  Macro
//
//  Created by michelle chandra on 07/11/23.
//

import SwiftUI

struct FloatingPanelAddFolder: View {
    var onClick: () -> Void
    
    @State var hoverStatus: Bool = false
    
    var body: some View {
        Button(action: {
            onClick()
        }) {
            Image(systemName: "plus")
                .padding(3)
                .padding(.trailing, 7)
                .font(.title3)
                .foregroundStyle(hoverStatus ? Color("StrongOrange") : .white)
        }
        .onHover(perform: { hovering in
            self.hoverStatus = hovering
        })
        .buttonStyle(.borderless)
    }
}

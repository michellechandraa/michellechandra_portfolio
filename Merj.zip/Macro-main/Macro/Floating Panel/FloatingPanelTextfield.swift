//
//  FloatingPanelTextfield.swift
//  Macro
//
//  Created by michelle chandra on 07/11/23.
//

import SwiftUI

struct FloatingPanelTextfield: View {
    @ObservedObject var viewModel: FloatingPanelViewModel
    
    @Binding var text: String
    @Binding var isTextFieldVisible: Bool
    @Binding var isAddFolderVisible: Bool
    @Binding var isSearchBarVisible: Bool
    
    @Binding var textfieldPlaceholder: String
    
    
    var placeholder: String
    
    var body: some View {
        HStack{
            TextField("\(placeholder)", text: $text)
                .textFieldStyle(.plain)
                .padding(7)
                .background(.clear)
                .font(.caption)
        }
        .background(VisualEffectView(material: .hudWindow, blendingMode: .withinWindow))
        .cornerRadius(4)
        .padding(.horizontal, 5)
        .frame(height: 18)
    }
}

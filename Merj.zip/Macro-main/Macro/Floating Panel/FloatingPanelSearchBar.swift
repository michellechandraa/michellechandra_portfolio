//
//  SearchBar.swift
//  Macro
//
//  Created by michelle chandra on 29/10/23.
//

import SwiftUI

struct FloatingPanelSearchBar: View {
    @ObservedObject var viewModel: FloatingPanelViewModel
    
    var onClick: () -> Void
    
    @State var hoverStatus: Bool = false
    
    var body: some View {
        
        Button(action: {
            onClick()}
        ){
            Image(systemName: "magnifyingglass")
                .font(.caption2)
                .padding(3)
                .foregroundStyle(viewModel.selectedProjectonPanel == nil ? .gray : (hoverStatus ? Color("StrongOrange") : .white))
        }
        .onHover(perform: { hovering in
            self.hoverStatus = hovering
        })
        .buttonStyle(.borderless)
    }
}

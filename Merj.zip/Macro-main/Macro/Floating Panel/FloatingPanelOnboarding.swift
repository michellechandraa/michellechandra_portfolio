//
//  FloatingPanelOnboarding.swift
//  Macro
//
//  Created by Evelyn Megawati Tiffany on 14/11/23.
//

import SwiftUI

struct FloatingPanelOnboarding: View {

    var body: some View {
        ZStack{
            VisualEffectView(material: .dark, blendingMode: .behindWindow)
                .frame(width: 150, height: 300)
                .cornerRadius(8)
        }
    }
}

#Preview {
    FloatingPanelOnboarding()
}

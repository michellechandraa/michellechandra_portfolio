//
//  FloatingPanelView.swift
//  Macro
//
//  Created by Felicia Graciella on 06/11/23.
//

import SwiftUI

struct FloatingPanelView: View, DropDelegate {
    
    @ObservedObject var rootVM: RootViewModel = RootViewModel()
    
    @StateObject var panelVM: FloatingPanelViewModel = FloatingPanelViewModel()

    /// - TextField
    @FocusState private var isTextFieldFocused: Bool
    
    @Environment(\.openWindow) private var openWindow
    
    @State var isPopoverPartOne: Bool = false
    @State var isPopoverPartTwo: Bool = false
    @State var isPopoverPartThree: Bool = false
    @State var isPopoverPartSix: Bool = false
    @State var isPopoverPartFive: Bool = false
    
    func performDrop(info: DropInfo) -> Bool {
        panelVM.savePhoto(lastFolder: panelVM.lastProject!.wrappedName)
        
        // CHANGE USERDEFAULTS TO 2
        if UserDefaults.standard.integer(forKey: "onboardingStatus") == 1 {
            UserDefaults.standard.set(2, forKey: "onboardingStatus")
         
            isPopoverPartThree = true
        }
        
        return true
    }
    
    var body: some View {
        ZStack{
            // Glassmorphism background using VisualEffectView
            VisualEffectView(material: .dark, blendingMode: .behindWindow)
                .onTapGesture {
                    // Hide text field and show the buttons
                    if panelVM.isTextfieldVisible {
                        panelVM.toggleUIVisibility()
                        isTextFieldFocused = false
                        panelVM.searchTextPanel = ""
                        panelVM.getAllProjectinPanel()
                        
                        if panelVM.textfieldPlaceholder == "Create Collection" {
                            panelVM.textfieldPlaceholder = "Search Collection"
                        }
                    }
                }
            
            VStack {
                HStack{
                    FloatingTrafficButton(isPopoverPartThree: $isPopoverPartThree){
                        NSApplication.shared.mainWindow?.close()
                    } maxClick: {
                        print("click")
                        
                        NSApplication.shared.mainWindow?.close()
                        
                        /// OPEN ROOT VIEW
                        NSApplication.shared.activate(ignoringOtherApps: true)
                        
                        openWindow(id: "Main App")
                    }
                    .padding(.horizontal, 15)
                    
                    Spacer()
                    
                    FloatingPanelScreenshoot(viewModel: panelVM, isPopoverPartSix: $isPopoverPartSix) {
                        panelVM.isCapturing.toggle()
                        
                        if UserDefaults.standard.integer(forKey: "onboardingStatus") == 4 {
                            UserDefaults.standard.set(5, forKey: "onboardingStatus")
                        }
                        
                    }
                    .disabled(rootVM.pinnedCollectionOnPanel == nil && panelVM.selectedProjectonPanel == nil || UserDefaults.standard.integer(forKey: "onboardingStatus") < 4)
                    .popover(isPresented: self.$isPopoverPartFive, arrowEdge: .bottom) {
                        PopOverView(text: "Use this for Screenshot")
                    }
                    .padding(.horizontal, 5)
                }
                .zIndex(1)
                .padding(.top, 3)
                
                if UserDefaults.standard.integer(forKey: "onboardingStatus") == 0  {
                    Text("No pinned Collection")
                        .foregroundColor(.white)
                        .font(.callout)
                        .frame(height: 124)
                } else if rootVM.pinnedCollectionOnPanel == nil && panelVM.selectedProjectonPanel == nil {
                    Text("No pinned Collection")
                        .foregroundColor(.white)
                        .font(.callout)
                        .frame(height: 124)
                } else {
                    FolderOnPanelView(projectName: $panelVM.selectedProjectName, projectPhoto: $panelVM.selectedProjectPhoto, projectPhotoMin1: $panelVM.selectedProjectPhotoMin1, projectPhotoMin2: $panelVM.selectedProjectPhotoMin2, onClick: {
                        NSApplication.shared.mainWindow?.close()
                        
                        panelVM.getLastProject()
                        
                        /// OPEN INSIDE FOLDER
                        NSApplication.shared.activate(ignoringOtherApps: true)
                        openWindow(id: "Main App")
                        UserDefaults.standard.set(true, forKey: "fromPanel")
                        
                        UserDefaults.standard.set(panelVM.lastProject?.name, forKey: "lastFolder")
                    })
                    .frame(height: 124)
                    .onDrop(of: ["public.image", "public.url"], delegate: self)
                    .onHover { status in
                        panelVM.onHover = status
                    }
                    
                    // MOVE TO ONBOARDING PART TWO
                    .onAppear{
                        if UserDefaults.standard.integer(forKey: "onboardingStatus") == 1 {
                            isPopoverPartTwo = true
                        } else {
                            isPopoverPartTwo = false
                        }
                    }
                    
                    // ONBOARDING PART TWO
                    .popover(isPresented: self.$isPopoverPartTwo, arrowEdge: .bottom) {
                        PopOverView(text: "Drag inspiration from \nmultiple sources and \ndrop it into the panel!")
                    }
                    
                    .popover(isPresented: self.$isPopoverPartSix, arrowEdge: .bottom) {
                        PopOverView(text: "Now you are set to go!")
                            .onAppear{
                                if UserDefaults.standard.integer(forKey: "onboardingStatus") == 5 {
                                    UserDefaults.standard.set(6, forKey: "onboardingStatus")
                                }
                            }
                    }
                }
                
                if panelVM.isExpanded {
                    /// Divider
                    Rectangle()
                        .frame(width: 124, height: 0.5)
                        .foregroundStyle(.white)
                        .padding(.vertical, 7)
                    ZStack{
                        /// The 'House' Rectangle
                        VisualEffectView(material: .hudWindow, blendingMode: .withinWindow)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .preferredColorScheme(.dark)
                        VStack{
                            HStack{
                                Group {
                                    if panelVM.textfieldPlaceholder == "Search Collection" {
                                        if panelVM.isSearchBarVisible{
                                            if UserDefaults.standard.integer(forKey: "onboardingStatus") == 0 {
                                            } else {
                                                Text("Recents")
                                            }
                                        } else {
                                            HStack {
                                                Text("Search")
                                                Spacer()
                                                Image(systemName: "xmark")
                                                    .font(.caption)
                                                    .bold()
                                                    .padding(5)
                                                    .onTapGesture {
                                                        panelVM.searchTextPanel = ""
                                                        
                                                        panelVM.isSearchBarVisible.toggle()
                                                        panelVM.isAddFolderVisible.toggle()
                                                        panelVM.isTextfieldVisible.toggle()
                                                        
                                                        panelVM.getAllProjectinPanel()
                                                        
                                                        if panelVM.textfieldPlaceholder == "Create Collection" {
                                                            panelVM.textfieldPlaceholder = "Search Collection"
                                                        }
                                                    }
                                            }
                                        }
                                    } else if panelVM.textfieldPlaceholder == "Create Collection" {
                                        HStack {
                                            Text("Create")
                                            Spacer()
                                            Image(systemName: "xmark")
                                                .font(.caption)
                                                .bold()
                                                .padding(7)
                                                .onTapGesture {
                                                    panelVM.searchTextPanel = ""
                                                    
                                                    panelVM.isSearchBarVisible.toggle()
                                                    panelVM.isAddFolderVisible.toggle()
                                                    panelVM.isTextfieldVisible.toggle()
                                                    
                                                    panelVM.getAllProjectinPanel()
                                                    
                                                    if panelVM.textfieldPlaceholder == "Create Collection" {
                                                        panelVM.textfieldPlaceholder = "Search Collection"
                                                    }
                                                    
                                                }
                                        }
                                    }
                                }
                                .padding(.leading, 7)
                                .font(.system(size: 10))
                                .foregroundStyle(.white)
                                
                                Spacer()
                                
                                if panelVM.isSearchBarVisible {
                                    FloatingPanelSearchBar(viewModel: panelVM) {
                                        panelVM.toggleUIVisibility()
                                        panelVM.textfieldPlaceholder = "Search Collection"
                                    }
                                    .disabled(rootVM.pinnedCollectionOnPanel == nil && panelVM.selectedProjectonPanel == nil)
                                    
                                }
                                if panelVM.isAddFolderVisible {
                                    FloatingPanelAddFolder {
                                        panelVM.toggleUIVisibility()
                                        panelVM.textfieldPlaceholder = "Create Collection"
                                        
                                    }
                                    
                                    // ONBOARDING PART ONE
                                    .popover(isPresented: $isPopoverPartOne, arrowEdge: .top) {
                                        PopOverView(text: "Click + to create a Collection!")
                                    }
                                }
                            }
                            
                            if panelVM.isTextfieldVisible {
                                FloatingPanelTextfield(viewModel: panelVM, text: $panelVM.searchTextPanel, isTextFieldVisible: $panelVM.isTextfieldVisible, isAddFolderVisible: $panelVM.isAddFolderVisible, isSearchBarVisible: $panelVM.isSearchBarVisible, textfieldPlaceholder: $panelVM.textfieldPlaceholder, placeholder: panelVM.textfieldPlaceholder)
                                    .focused($isTextFieldFocused)
                                    .onChange(of: panelVM.searchTextPanel) { _, filter in
                                        
                                        if panelVM.textfieldPlaceholder == "Search Collection" {
                                            if panelVM.searchTextPanel != "" {
                                                panelVM.getFilteredProjectinPanel(filter: filter)
                                            } else {
                                                panelVM.resultTextPanel = ""
                                                panelVM.getAllProjectinPanel()
                                            }
                                        }
                                        
                                        if panelVM.searchTextPanel == "" {
                                            panelVM.saveStatus = ""
                                        }
                                    }
                                    .onAppear {
                                        if panelVM.searchTextPanel == "" {
                                            panelVM.saveStatus = ""
                                        }
                                    }
                                    .onSubmit {
                                        if panelVM.textfieldPlaceholder == "Create Collection" {
                                            if !panelVM.searchTextPanel.isEmpty {
                                                
                                                panelVM.saveProject()
                                                
                                                if !panelVM.alreadyExist {
                                                    // CHANGE USERDEFAULTS TO 1 HERE
                                                    panelVM.pinProject(projectName: panelVM.searchTextPanel)
                                                    
                                                    panelVM.searchTextPanel = ""
                                                    
                                                    panelVM.textfieldPlaceholder = "Search Collection"
                                                    
                                                    panelVM.toggleUIVisibility()
                                                    panelVM.getAllProjectinPanel()
                                                }
                                                panelVM.alreadyExist = false
                                            }
                                        }
                                    }
                                
                                if panelVM.textfieldPlaceholder == "Search Collection" {
                                    HStack{
                                        Text(panelVM.resultTextPanel)
                                            .padding(.leading, 7)
                                            .padding(.top, 1)
                                            .font(.system(size: 10, weight: .thin))
                                            .foregroundStyle(.white)
                                        Spacer()
                                    }
                                } else if panelVM.textfieldPlaceholder == "Create Collection" {
                                    HStack{
                                        Text(panelVM.saveStatus)
                                            .padding(.leading, 7)
                                            .padding(.top, 1)
                                            .font(.system(size: 10, weight: .thin))
                                            .foregroundStyle(.white)
                                        Spacer()
                                    }
                                }
                            }
                            
                            /// floating panel expanded when clicked
                            if (UserDefaults.standard.integer(forKey: "onboardingStatus") == 0 && panelVM.isSearchBarVisible && panelVM.isAddFolderVisible) || (panelVM.projects.count < 1 && panelVM.isSearchBarVisible && panelVM.isAddFolderVisible)  {
                                Text("No Collection found")
                                    .foregroundStyle(Color(.white))
                                    .font(.caption)
                                    .padding()
                            } else {
                                if panelVM.textfieldPlaceholder == "Search Collection" {
                                    if panelVM.isSearchBarVisible{
                                        ScrollView(.vertical) {
                                            ForEach(panelVM.searchTextPanel.isEmpty ? panelVM.projects.prefix(panelVM.projectCount) : panelVM.projects.prefix(panelVM.projects.count), id: \.self) { project in
                                                FloatingPanelFoldersView(folderName: project.wrappedName) {
                                                    
                                                    panelVM.pinProject(projectName: project.wrappedName)
                                                    
                                                    panelVM.getLastProject()
                                                    
                                                    
                                                    if panelVM.isExpanded {
                                                        panelVM.isExpanded = false
                                                    }
                                                    panelVM.getAllProjectinPanel()
                                                }
                                                .padding(.horizontal, 8)
                                            }
                                            .animation(panelVM.isExpanded ? .smooth : .default)
                                        }
                                        .frame(maxHeight: 210)
                                        .scrollDisabled(panelVM.projectCount <= 5)
//                                    }
                                        
                                    } else if !panelVM.searchTextPanel.isEmpty {
                                        ScrollView(.vertical) {
                                            ForEach(panelVM.searchTextPanel.isEmpty ? panelVM.projects.prefix(panelVM.projectCount) : panelVM.projects.prefix(panelVM.projects.count), id: \.self) { project in
                                                FloatingPanelFoldersView(folderName: project.wrappedName) {
                                                    
                                                    panelVM.pinProject(projectName: project.wrappedName)
                                                    
                                                    panelVM.getLastProject()
                                                    
                                                    if panelVM.isExpanded {
                                                        panelVM.isExpanded = false
                                                    }
                                                    panelVM.getAllProjectinPanel()
                                                }
                                                .padding(.horizontal, 8)
                                            }
                                            .animation(panelVM.isExpanded ? .smooth : .default)
                                        }
                                        .frame(maxHeight: 210)
                                        .scrollDisabled(panelVM.projectCount <= 5)
                                    }
                                }
                            }
                            Spacer()
                        }
                        .padding(.top, 5)
                    }
                    .padding(.horizontal, 8)
                    
                    Button(action: {
                        // Toggle the showingPanel state to expand or collapse the panel
                        panelVM.isExpanded.toggle()
                        panelVM.textfieldPlaceholder = "Search Collection"
                    }) {
                        FloatingChevron(chevron: "chevron.up")
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(10)
                } else {
                    Button(action: {
                        if panelVM.isTextfieldVisible {
                            panelVM.toggleUIVisibility()
                            isTextFieldFocused = false
                            panelVM.searchTextPanel = ""
                            panelVM.getAllProjectinPanel()
                            
                            
                        }
                        // Toggle the showingPanel state to expand or collapse the panel
                        panelVM.isExpanded.toggle()
                    }) {
                        FloatingChevron(chevron: "chevron.down")
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(2)
                }
            }
        }
        
        
        .onAppear {
            print(UserDefaults.standard.integer(forKey: "onboardingStatus"))
            if UserDefaults.standard.integer(forKey: "onboardingStatus") >= 6{
                panelVM.placePanel(to: .centerRight)
            }
            
            // ONBOARDING PART ONE
            if UserDefaults.standard.integer(forKey: "onboardingStatus") == 0 {
                isPopoverPartOne = true
            } else {
                isPopoverPartOne = false
            }
            
            if UserDefaults.standard.integer(forKey: "onboardingStatus") == 4 {
                isPopoverPartFive = true
            } else {
                isPopoverPartFive = false
            }
            
            
            
            if isPopoverPartOne == true {
                panelVM.isExpanded = true
            }
            
            panelVM.selectedProjectonPanel = Projects.getSpecificProject(filter: panelVM.lastProject?.wrappedName ?? "")
            rootVM.pinnedCollectionOnPanel = Projects.getSpecificProject(filter: rootVM.lastProject?.wrappedName ?? "")
            
            print(panelVM.selectedProjectonPanel?.name)
            print(rootVM.pinnedCollectionOnPanel?.name)
            
            panelVM.pinProject(projectName: panelVM.lastProject?.wrappedName ?? "")
        }
        .frame(width: 150)
        .fixedSize()
        .clipShape(RoundedRectangle(cornerRadius: 8))
        
    }
}

//
//  FloatingPanelViewModel.swift
//  Macro
//
//  Created by Felicia Graciella on 09/11/23.
//

import Foundation
import SwiftUI
import AVKit

class FloatingPanelViewModel: ObservableObject {
    
    /// PANEL VARIABLES
    @Published var showingPanel = false
    @Published var position: CGPoint = .zero
    @Published var isExpanded = false
    @Published var panelHeight: CGFloat = 191
    @Published var onHover: Bool = false
    
    /// PANEL ADD AND SEARCH BUTTON VARIABLES
    @Published var isSearchBarVisible = true
    @Published var isAddFolderVisible = true
    @Published var isTextfieldVisible = false
    @Published var textfieldPlaceholder = "Search Collection"
    
    /// VIEW CONTEXT
    private var moc = DataProvider.shared.viewContext
    
    
    
    
    /// INI YANG DIGANTI
    @Published var lastProject: Projects?
    @Published var projects: [Projects] = []
    

    init() {
        getLastProject()
        
        projects = Projects.getAllProject(filter: "", selectedProject: lastProject?.wrappedName)
    }
    
    func getLastProject() {
        do {
            if let managedObjectID = UserDefaults.retrieveManagedObjectID(with: "lastProject"),
               let managedObject = try DataProvider.shared.viewContext.existingObject(with: managedObjectID) as! Projects? {
                
                if managedObject.del == false {
                    lastProject = managedObject
                    
                    selectedProjectonPanel = managedObject
                } else {
                    lastProject = projects.first
                    selectedProjectonPanel = lastProject
                }
            }
            
        } catch {
            print("error")
        }
    }
    
    func toggleUIVisibility() {
        isSearchBarVisible.toggle()
        isAddFolderVisible.toggle()
        isTextfieldVisible.toggle()
    }
    
    /// SAVE PHOTO
    @Published var image = Image(systemName: "photo")
    @Published var imageURL: URL?
    
    @Published var isCapturing = false
    
    @Published var audioPlayer: AVAudioPlayer!
    
    func savePhoto(lastFolder: String) {
        image = Image(systemName: "photo")
        imageURL = nil
        
        let photo1 = Photos(context: moc)
        
        var pasteboard = NSPasteboard(name: .drag)
        
        if isCapturing {
            pasteboard = NSPasteboard.general
        }
        
        
        let sound = Bundle.main.path(forResource: "DropSFX", ofType: "m4a")
        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
        
        // it returns the content of the public.url → is an encoded message url
        DispatchQueue.main.async {
            if let anys = pasteboard.readObjects(forClasses: [NSImage.self]),
               let nsImg = anys.first as? NSImage {
                
                if let tiffData = nsImg.tiffRepresentation,
                       let bitmapImage = NSBitmapImageRep(data: tiffData) {
                        if let pngData = bitmapImage.representation(using: .png, properties: [:]) {
                            
                            /// - insert photo to core data
                            photo1.photo = pngData
                        }
                    }
                
                if let anys = pasteboard.readObjects(forClasses: [NSURL.self]),
                   let url = anys.first as? URL {
                    
                    
                    /// - insert link to core data
                    if !url.absoluteString.contains("file") {
                        self.imageURL = url
                        
                        photo1.link = self.imageURL?.absoluteString
                    } else {
                        photo1.link = nil
                    }
                    
                    
                    print("🏖️ \(url.absoluteString)")
                }
                
                /// - other photo properties
                photo1.id = UUID()
                photo1.dateCreated = Date.now
                photo1.ownedBy = Projects.getSpecificProject(filter: lastFolder)
                
                photo1.note = ""
                
                photo1.del = false
                
                /// - update project last modified
                self.updateProject()
                
                do {
                    try self.moc.save()
                    print("saved")
                    
//                    self.whenSaved()
                    self.audioPlayer.play()
                    
                    self.selectedProjectonPanel = Projects.getSpecificProject(filter: lastFolder)
                    
                    if self.isCapturing {
                        self.isCapturing.toggle()
                    }
                } catch let error as NSError {
                  print("Could not save. \(error), \(error.userInfo)")
                }
            }
        }
    }
    
    
    func updateProject() {
        if let lastCollectionName = lastProject?.wrappedName {
            let thisProject = Projects.getSpecificProject(filter: lastCollectionName)
            
            thisProject?.dateModified = Date.now
        }
        
    }
    
    /// SELECTED FOLDER IN PANEL
    @Published var selectedProjectName: String?
    @Published var selectedProjectPhoto: Data?
    
    @Published var selectedProjectPhotoMin1: Data?
    @Published var selectedProjectPhotoMin2: Data?
    
    @Published var selectedProjectonPanel: Projects? {
        didSet {
            if let selectedProjectonPanel {
                selectedProjectName = selectedProjectonPanel.wrappedName
                
                if let folderPhoto = selectedProjectonPanel.photoArray.last,
                   let imgData = folderPhoto.photo {
                    selectedProjectPhoto = imgData
                    
                    if selectedProjectonPanel.photoArray.count >= 2 {
                        let folderPhoto1 = selectedProjectonPanel.photoArray[selectedProjectonPanel.photoArray.count-2]
                        let imgData = folderPhoto1.photo
                        
                        selectedProjectPhotoMin1 = imgData
                        
                        if selectedProjectonPanel.photoArray.count >= 3 {
                            let folderPhoto1 = selectedProjectonPanel.photoArray[selectedProjectonPanel.photoArray.count-3]
                            let imgData = folderPhoto1.photo
                            
                            selectedProjectPhotoMin2 = imgData
                        } else {
                            selectedProjectPhotoMin2 = nil
                        }
                        
                    } else {
                        selectedProjectPhotoMin1 = nil
                        selectedProjectPhotoMin2 = nil
                    }
                    
                } else {
                    selectedProjectPhoto = nil
                    selectedProjectPhotoMin1 = nil
                    selectedProjectPhotoMin2 = nil
                }
                
            } else {
                if let lastProject {
                    selectedProjectName = lastProject.wrappedName
                    
                    if let folderPhoto =  lastProject.photoArray.last,
                       let imgData = folderPhoto.photo {
                        selectedProjectPhoto = imgData
                        
                        if lastProject.photoArray.count >= 2 {
                            let folderPhoto1 = lastProject.photoArray[lastProject.photoArray.count-2]
                            let imgData = folderPhoto1.photo
                            
                            selectedProjectPhotoMin1 = imgData
                            
                            if lastProject.photoArray.count >= 3 {
                                let folderPhoto1 =  lastProject.photoArray[(lastProject.photoArray.count)-3]
                                let imgData = folderPhoto1.photo
                                
                                selectedProjectPhotoMin2 = imgData
                            } else {
                                selectedProjectPhotoMin2 = nil
                            }
                            
                        } else {
                            selectedProjectPhotoMin1 = nil
                            selectedProjectPhotoMin2 = nil
                        }
                        
                    } else {
                        selectedProjectPhoto = nil
                        selectedProjectPhotoMin1 = nil
                        selectedProjectPhotoMin2 = nil
                    }
                } else {
                    selectedProjectName = "Unknown"
                    
                    selectedProjectPhoto = nil
                    selectedProjectPhotoMin1 = nil
                    selectedProjectPhotoMin2 = nil
                    
                }
                
            }
            self.objectWillChange.send()
        }
    }
    
    /// GET PROJECTS IN PANEL
    func getAllProjectinPanel() {
        projects = Projects.getAllProject(filter: "", selectedProject: lastProject?.wrappedName)
        
        projectCount = 5
    }
    
    @Published var resultTextPanel = ""
    
    /// SEARCH BAR IN PANEL
    @Published var searchTextPanel = ""
    
    /// GET FILTERED PROJECT IN PANEL
    func getFilteredProjectinPanel(filter: String) {
        if searchTextPanel != "" {
            projects = Projects.getAllProject(filter: filter, selectedProject: lastProject!.wrappedName)
            print(projects.count)
            
            if projects.count != 0 {
                resultTextPanel = "Results"
            } else {
                resultTextPanel = "No result found"
            }
        } else {
            resultTextPanel = ""
            
            getAllProjectinPanel()
            print(projects.count)
        }
        
        projectCount = projects.count
    }
    
    @Published var projectCount = 5
    
    /// SAVE PROJECT
    @Published var alreadyExist = false
    @Published var saveStatus = ""
    
    func saveProject() {
        let fetchRequest: NSFetchRequest<Projects>
        fetchRequest = Projects.fetchRequest()

        fetchRequest.predicate = NSPredicate(
            format: "name == %@", searchTextPanel
        )
        
        do {
            let test = try moc.fetch(fetchRequest)
            
            if test.count >= 1 {
                alreadyExist = true
                saveStatus = "Collection already exists"
            } else {
                let project1 = Projects(context: moc)
                
                if searchTextPanel != "" {
                    project1.name = searchTextPanel
                }
                
                
                project1.id = UUID()
                project1.dateCreated = Date.now
                project1.dateModified = Date.now
                project1.del = false
                
                do {
                    try moc.save()
                    saveStatus = "Collection saved"
                    print("saved")
                    
                    
                    getAllProjectinPanel()
                    
                    
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        } catch {
            print(error)
        }
        
        
    }
    
    func pinProject(projectName: String) {
        if !projectName.isEmpty {
            if UserDefaults.standard.integer(forKey: "onboardingStatus") == 0 {
                UserDefaults.standard.set(1, forKey: "onboardingStatus")
            }
            
            if projectName != "" {
                
                selectedProjectonPanel = Projects.getSpecificProject(filter: projectName)
            } else {
                UserDefaults.standard.removeObject(forKey: "lastProject")
                
                selectedProjectonPanel = nil
            }

            if let selectedProjectonPanel {
                UserDefaults.save(managedObjectID: selectedProjectonPanel.objectID, with: "lastProject")
                                
                do {
                    let managedObject = try DataProvider.shared.viewContext.existingObject(with: UserDefaults.retrieveManagedObjectID(with: "lastProject") ?? NSManagedObjectID()) as? Projects
                    lastProject = managedObject
                    
                } catch {
                    // Handle the error here if needed
                    print("Error: \(error)")
                }
            }
        
            
        }
        
        
    }
    
    func placePanel(to: ScreenSide) {
        guard let screenSize = NSScreen.main?.visibleFrame.size else { return }
        
        guard let window = NSApplication.shared.mainWindow else { return }
        let windowSize = window.frame.size
        
        var x: Double = 0
        var y: Double = 0
        
        switch to {
        case .topRight:
            x = screenSize.width - windowSize.width
            y = screenSize.height - (windowSize.height * 1.4)
            
        case .centerRight:
            x = screenSize.width - windowSize.width
            y = (screenSize.height - windowSize.height)/1.5
            
        case .center:
            x = (screenSize.width - windowSize.width)/2
            y = (screenSize.height - windowSize.height)/2
        }
        
        window.setFrame(.init(origin: CGPoint(x: x, y: y), size: windowSize), display: true, animate: true)
    }
}

enum ScreenSide {
    case topRight
    case centerRight
    case center
}

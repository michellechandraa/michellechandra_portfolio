//
//  FloatingPanelExtension.swift
//  Macro
//
//  Created by Felicia Graciella on 10/10/23.
//


/// LIAT LAGI NANTI DIPAKE APA NGGA
import SwiftUI

extension View {
    @ViewBuilder
    func floatingWindow<Content: View>(position: CGPoint, show: Binding<Bool>, @ViewBuilder content: @escaping () -> Content) ->some View{
        self.modifier(FloatingPanelModifier(windowView: content(), position: position, show: show))
    }
}

//
//  FloatingPanelHelper.swift
//  Macro
//
//  Created by Felicia Graciella on 10/10/23.
//


/// LIAT LAGI NANTI DIPAKE APA NGGA
import SwiftUI

class FloatingPanelHelper<Content: View>: NSPanel {
    @Binding private var showingPanel: Bool
    
    init(position: CGPoint, showingPanel: Binding<Bool>, @ViewBuilder content: @escaping()-> Content){
        self._showingPanel = showingPanel
        
        super.init(contentRect: .zero,
                   styleMask: [.nonactivatingPanel, /*.titled,*/ .resizable, .closable, .fullSizeContentView],
                   backing: .buffered,
                   defer: false)
        
        /// Allow the panel to be on top of other windows
        isFloatingPanel = true
        level = .mainMenu
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        orderFrontRegardless()
        
        backgroundColor = .clear
        hasShadow = true
        
        /// Don't show a window title, even if it's set
        titleVisibility = .hidden
        titlebarAppearsTransparent = true
        
        /// Since there is no title bar make the window moveable by dragging on the background
        isMovableByWindowBackground = true
        isMovable = true
        
        /// Hide when unfocused
        hidesOnDeactivate = false
        
        /// Hide all traffic light buttons
        standardWindowButton(.closeButton)?.isHidden = true
        standardWindowButton(.miniaturizeButton)?.isHidden = true
        standardWindowButton(.zoomButton)?.isHidden = true
        
        /// Set the content view.
        /// The safe area is ignored because the title bar still interferes with the geometry
        contentView = NSHostingView(rootView: content())
    }
    
    func updatePosition(_ to: CGPoint) {
        /// - optional animating while travelling
        let fittingSize = contentView?.fittingSize ?? .zero
        self.setFrame(.init(origin: to, size: fittingSize), display: true, animate: true)
    }
    
    /// - dynamic updation when the panel is closed
    override func close() {
        super.close()
        showingPanel = false
    }
    
    // `canBecomeKey` and `canBecomeMain` are required so that text inputs inside the panel can receive focus
      override var canBecomeKey: Bool {
        return true
      }

      override var canBecomeMain: Bool {
        return true
      }
}

//
//  FloatingWindowModifier.swift
//  Macro
//
//  Created by Felicia Graciella on 10/10/23.
//


/// LIAT LAGI NANTI DIPAKE APA NGGA
import SwiftUI

struct FloatingPanelModifier<WindowView: View>: ViewModifier{
    var windowView: WindowView
    var position: CGPoint
    @Binding var show: Bool
    @State private var panel: FloatingPanelHelper<WindowView>?
    
    func body(content: Content) -> some View {
        content
            .onAppear {
                /// - Creating and storing panel for future view updates
                panel = FloatingPanelHelper(position: position, showingPanel: $show, content: {
                    windowView
                })
                /// - To place panel at center by default
                panel?.center()
            }
            /// - for swiftUI View Updation on Panel View
            .background(content:{
                FloatingPanelViewUpdater(content: windowView, panel: $panel)
            })
            /// - updating position dynamically
            .onChange(of: position, perform: { newValue in
                panel?.updatePosition(newValue)
            })
        
            .onChange(of: show) { newValue in
                /// - When ever show is toggled presenting floating panel
                if newValue{
                    panel?.orderFront(nil)
                    panel?.makeKey()
                } else {
                    /// - removing panel
                    panel?.close()
                }
                
            }
    }
}

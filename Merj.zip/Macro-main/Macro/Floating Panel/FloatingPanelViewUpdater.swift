//
//  FloatingPanelViewUpdater.swift
//  Macro
//
//  Created by Felicia Graciella on 10/10/23.
//

/// LIAT LAGI NANTI DIPAKE APA NGGA
import SwiftUI

struct FloatingPanelViewUpdater<Content: View>: NSViewRepresentable{

    var content: Content
    @Binding var panel: FloatingPanelHelper<Content>?

    func makeNSView(context: Context) -> NSView {
        return NSView()
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        if let hostingView = panel?.contentView as? NSHostingView<Content>{
            hostingView.rootView = content
        }
    }

}

//
//  FolderOnPanelView.swift
//  Macro
//
//  Created by Felicia Graciella on 18/10/23.
//

import SwiftUI

struct FolderOnPanelView: View {
    var imageSize: CGFloat = 124
    
    @State var hoverStatus: Bool = false
    
    @Binding var projectName: String?
    @Binding var projectPhoto: Data?
    
    @Binding var projectPhotoMin1: Data?
    @Binding var projectPhotoMin2: Data?
    
    var onClick: () -> Void
    
    var body: some View {
        Button(action: {
            onClick()
        }, label: {
            ZStack {
                /// Collection photo - 2
                if let projectPhotoMin2,
                   let nsImg = NSImage(data: projectPhotoMin2){

                    Image(nsImage: nsImg)
                        .resizable()
                        .frame(width: 101, height: 116.5)
                        .scaledToFill()
                        .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
                        .shadow(color: .darkGray, radius: 2, x: 1, y: 1)
                        .overlay(RoundedRectangle(cornerRadius: 4)
                            .stroke(.primary, lineWidth: 0.1)
                            .fill(.black)
                            .opacity(0.5))
                        .rotationEffect(.degrees(-10.76))
                        .padding(.bottom, 12)
                } else {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(.offWhite)
                        .frame(width: 101, height: 116.5)
                        .rotationEffect(.degrees(-10.76))
                        .padding(.bottom, 12)
                        .shadow(color: .darkGray, radius: 2, x: 1, y: 1)
                }
                    
                
                /// collection photo - 1
                if let projectPhotoMin1,
                   let nsImg = NSImage(data: projectPhotoMin1){

                    Image(nsImage: nsImg)
                        .resizable()
                        .frame(width: 109.5, height: 117)
                        .scaledToFill()
                        .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
                        .shadow(color: .darkGray, radius: 2, x: 1, y: 1)
                        .overlay(RoundedRectangle(cornerRadius: 4)
                            .stroke(.primary, lineWidth: 0.1)
                            .fill(.black)
                            .opacity(0.3))
                        .rotationEffect(.degrees(-5.34))
                        .padding(.bottom, 8)
                } else {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(.white)
                        .frame(width: 109.5, height: 117)
                        .rotationEffect(.degrees(-5.34))
                        .padding(.bottom, 8)
                        .shadow(color: .darkGray, radius: 2, x: 1, y: 1)
                }
                
                /// collection photo
                if let projectPhoto,
                   let nsImg = NSImage(data: projectPhoto){

                    Image(nsImage: nsImg)
                        .resizable()
                        .scaledToFill()
                        .frame(width: imageSize, height: imageSize)
                        .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
                        .shadow(color: .darkGray, radius: 2, x: 0.5, y: 0.5)
                        .overlay(RoundedRectangle(cornerRadius: 4)
                            .stroke(.primary, lineWidth: 0.1))
                } else {
                    RoundedRectangle(cornerRadius: 4)
                        .foregroundStyle(Color("LilDarkGray"))
                        .frame(width: imageSize, height: imageSize)
                        .shadow(color: .darkGray, radius: 2, x: 0.5, y: 0.5)

                    Text("Drop Media Here")
                        .padding(.top, -20)
                        .font(.system(size: 11))
                }

                VStack {
                    Spacer()
                    ZStack {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color("OffWhite"))
                            .frame(width: imageSize, height: 34)
                            .padding(.vertical, imageSize/50)

                        Text(projectName ?? "Add Project First")
                            .lineLimit(2)
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(.black)
                            .padding(.horizontal, 7)
                            .font(.system(size: 11))
                            .frame(width: imageSize, height: 34, alignment: .leading)
                    }
                }
            }
            .onHover(perform: { hovering in
                self.hoverStatus = hovering
            })
         })
        .buttonStyle(PlainButtonStyle())
    }
}

//
//  FloatingPanelScreenshoot.swift
//  Macro
//
//  Created by michelle chandra on 07/11/23.
//

import SwiftUI

struct FloatingPanelScreenshoot: View {
    @ObservedObject var viewModel: FloatingPanelViewModel
    @Binding var isPopoverPartSix: Bool
    var onClick: () -> Void
    
    @State var hoverStatus: Bool = false
    
    @State private var images: [NSImage] = []

    var body: some View {
        Button(action: {
            onClick()
            if screenshotWindowAndSuccess() {
                let image = getImageFromPasteboard()
                images.append(image)
                viewModel.savePhoto(lastFolder: viewModel.lastProject?.wrappedName ?? "")
                
                if UserDefaults.standard.integer(forKey: "onboardingStatus") == 5 {
                    UserDefaults.standard.set(6, forKey: "onboardingStatus")

                    isPopoverPartSix = true
                }
            }
        }){
            Image(systemName: "camera.viewfinder")
                .padding(4)
                .font(.title2)
                .foregroundStyle(viewModel.selectedProjectonPanel == nil || UserDefaults.standard.integer(forKey: "onboardingStatus") < 4 ? .gray : (hoverStatus ? Color("StrongOrange") : .white))
        }
        .onHover(perform: { hovering in
            self.hoverStatus = hovering
        })
        .buttonStyle(.borderless)
    }
    
    func screenshotWindowAndSuccess() -> Bool {
        let task = Process()
        task.launchPath = "/usr/sbin/screencapture"
        task.arguments = ["-cs"]
        task.launch()
        task.waitUntilExit()
        let status = task.terminationStatus
        return status == 0
    }
    
    func getImageFromPasteboard() -> NSImage {
        let pasteboard = NSPasteboard.general
        return (pasteboard.canReadItem(withDataConformingToTypes: NSImage.imageTypes) ? NSImage(pasteboard: pasteboard) : NSImage(named: NSImage.folderSmartName)) ?? NSImage()
    }
}

//
//  FloatingTrafficButton.swift
//  Macro
//
//  Created by michelle chandra on 09/11/23.
//

import SwiftUI

struct FloatingTrafficButton: View {
    @Binding var isPopoverPartThree: Bool
    
    var closeClick: () -> Void
    var maxClick: () -> Void

    @State var hoverStatus: Bool = false
    @State var hoverStatus2: Bool = false
    
    
    
    var body: some View {
        
        HStack{
            //close
            Button(action: {
                closeClick()
            }) {
                Image(systemName: "xmark")
                    .foregroundStyle( .black.opacity(0.5))
                    .font(.system(size: 8))
                    .bold()
                    .padding(.top, 1)
                    .background(Circle()
                        .fill(.red)
                        .fill(hoverStatus ? .black.opacity(0.15) : .red)
                        .frame(width: 13, height: 13))
            }
            .buttonStyle(BorderlessButtonStyle())
            .onHover(perform: { hovering in
                self.hoverStatus = hovering
            })
            
            
            //fullscreen
            Button(action: {
                maxClick()
                
                // CHANGE USERDEFAULTS TO 3
                if UserDefaults.standard.integer(forKey: "onboardingStatus") == 2 {
                    UserDefaults.standard.set(3, forKey: "onboardingStatus")
                }
            }) {
                Image(systemName: "pip.exit")
                    .foregroundStyle(hoverStatus2 ? Color("StrongOrange") : .white)
                    .frame(width: 12, height: 12)
                    .padding(.top, 1)
                    .padding(3)
                    .padding(.horizontal, 3)
            }
            .onHover(perform: { hovering in
                self.hoverStatus2 = hovering
            })
            .popover(isPresented: self.$isPopoverPartThree, arrowEdge: .bottom) {
                PopOverView(text: "Click to access \nall Collections")
            }
            .buttonStyle(.plain)
            
            Spacer()
        }
        .frame(alignment: .topLeading)
        
    }
}

//
//  FloatingPanelSettings.swift
//  Macro
//
//  Created by Felicia Graciella on 10/11/23.
//

import AppKit
import SwiftUI

class FloatingPanelSettings<Content: View>: NSPanel {
    
    /// `canBecomeKey` and `canBecomeMain` are required so that text inputs inside the panel can receive focus
    override var canBecomeKey: Bool {
        return true
    }
    
    override var canBecomeMain: Bool {
        return true
    }
    
    init(view: Content) {
        /// - Your costum window mask's goes here
        super.init(contentRect: .zero,
                   styleMask: [.nonactivatingPanel, .closable, .fullSizeContentView],
                   backing: .buffered,
                   defer: false)
        
        /// - Set this if you want the panel to remember its size/position
//        self.setFrameAutosaveName("a unique name")
        
        /// - Allow the pannel to be on top of almost all other windows
        self.level = .floating
        self.isFloatingPanel = true
        
        /// - Allow the panel to appear in all spaces and a fullscreen space
        self.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        
        /// - Hiding titlebar
        self.titleVisibility = .hidden
        self.titlebarAppearsTransparent = true
        
        /// - Make the window moveable by click-dragging on the background
        self.isMovableByWindowBackground = true
        
        /// - Keep the panel around after closing since I expect the user to open/close it often
        self.isReleasedWhenClosed = false
        
        /// - Activate this if you want the window to hide once it is no longer focused
//        self.hidesOnDeactivate = true
        
        /// - Removing all traffic buttons
        self.standardWindowButton(.closeButton)?.isHidden = true
        self.standardWindowButton(.miniaturizeButton)?.isHidden = true
        self.standardWindowButton(.zoomButton)?.isHidden = true
        
        /// - Removing background color
        self.backgroundColor = .clear
        
        self.contentView = NSHostingView(rootView: view)

        /// - put the panel on center of screen
        self.center()

        /// Shows the panel and makes it active
        self.orderFront(nil)
        self.makeKey()
    }
}

//
//  FloatingPanelFoldersView.swift
//  Macro
//
//  Created by Felicia Graciella on 16/10/23.
//

import SwiftUI

struct FloatingPanelFoldersView: View {
    var buttonImage: Projects?
    
    var folderName: String
    
    var onClick: () -> Void
    
    @State var hoverStatus: Bool = false
    
    var body: some View {
        Button(action: {
            onClick()
        }) {
            ZStack {
                if(buttonImage?.photoArray.count != 0) {
                    ZStack{
                        /// onHover Overlay
                        RoundedRectangle(cornerRadius: 4)
                            .frame(width: .infinity, height: 34)
                            .foregroundStyle(hoverStatus ? .white.opacity(0.3) : .white.opacity(0.3))
                        
                        Image(systemName: "pin")
                            .rotationEffect(.degrees(45))
                            .font(.system(size: 16))
                            .foregroundColor(hoverStatus ? .white : .clear)
                    }
                } else {
                    Rectangle()
                        .frame(width: .infinity, height: 34)
                        .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
                }
                
                HStack{
                    Text(folderName)
                        .lineLimit(2)
                        .foregroundColor(hoverStatus ? .clear : .black)
                        .padding(.horizontal, 7)
                        .font(.system(size: 11))
                    Spacer()
                }
                
            }
        }
        .buttonStyle(PlainButtonStyle())
        .onHover(perform: { hovering in
            self.hoverStatus = hovering
        })
    }
}

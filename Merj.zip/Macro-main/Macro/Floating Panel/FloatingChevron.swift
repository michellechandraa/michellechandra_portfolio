//
//  FloatingChevron.swift
//  Macro
//
//  Created by michelle chandra on 07/11/23.
//

import SwiftUI

struct FloatingChevron: View {
    @State var hoverStatus: Bool = false
    
    var chevron: String
    
    var body: some View {
        Image(systemName: "\(chevron)")
            .foregroundColor(hoverStatus ? Color("StrongOrange") : .white)
            .font(.system(size: 16))
            .padding(.top, 5)
            .padding(.bottom, 4)
            .onHover(perform: { hovering in
                self.hoverStatus = hovering
            })
    }
}

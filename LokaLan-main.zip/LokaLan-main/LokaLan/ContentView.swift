//
//  ContentView.swift
//  LokaLan
//
//  Created by Haning Galih Rani Kumbara on 21/06/23.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    var body: some View {
        
        NavigationStack {
            WordLibraryView()
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  LokaLanApp.swift
//  LokaLan
//
//  Created by Haning Galih Rani Kumbara on 21/06/23.
//

import SwiftUI

@main
struct LokaLanApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView().environment(\.colorScheme, .light)
        }
    }
}

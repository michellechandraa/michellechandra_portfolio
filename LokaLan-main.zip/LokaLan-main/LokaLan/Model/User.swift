//
//  User.swift
//  LokaLan
//
//  Created by Haning Galih Rani Kumbara on 13/07/23.
//

import Foundation

struct UserModel{
    var name: String
    var id: Int
    var email: String
}


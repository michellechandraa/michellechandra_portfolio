//
//  widget_lokalanBundle.swift
//  widget_lokalan
//
//  Created by Andreas Lim on 08/07/23.
//

import WidgetKit
import SwiftUI

@main
struct widget_lokalanBundle: WidgetBundle {
    var body: some Widget {
        widget_lokalan()
    }
}

import SwiftUI

struct ContentView: View {
    @State private var emojis = ["🧸", "🎀", "🎈", "🪆", "🛍️", "📿", "🎏", "🚗","🧩", "🎮", "🎲", "⚽️", "🏀", "🏸", "🛼"]
    @State private var start = false
    @State private var timeRemaining = 10
    @State var timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State private var isButtonActive = true
    @State private var buttonText = "CLEAN UP"
    @State var paused = true
    @State var showingPopUp = false
    @State private var textSwitch = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Image("Background") //Background
                    .resizable()
                    .scaledToFill()
                    .aspectRatio(geometry.size, contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
            }
            
            //Emoji's Place
            VStack{
                GeometryReader { geo in
                    ForEach(emojis, id: \.self) { emoji in
                        Text(emoji)
                            .font(.system(size: 40))
                            .onTapGesture {
                                if timeRemaining > 0 && timeRemaining != 10{
                                    removeEmoji(emoji)
                                } else if timeRemaining == 10 && buttonText == "MESS UP AGAIN" || timeRemaining == 10 && buttonText == "CLEAN UP"{
                                }
                            }
                            .position(randomPoint(in: geo.frame(in: .local)))
                    }
                }
                .offset(y: 450)
                
                //Time Remaining
                Text("Time Remaining : \(timeRemaining)")
                                .font(.headline)
                                .padding()
                                .onReceive(timer) { _ in
                                    if timeRemaining > 0 && buttonText == "MESS UP AGAIN" && paused == false{
                                        timeRemaining -= 1
                                        if emojis == [] {
                                            showingPopUp = true
                                            timeRemaining = 0
                                        }
                                    } else {
                                        paused = true
//                                        timeRemaining = 15
                                        isButtonActive = true
                                        if timeRemaining == 0 && emojis != []{
                                            showingPopUp = true
                                        }
                                        timeRemaining = 10
                                    }
                                }
                                // PopOver
                                .sheet(isPresented: $showingPopUp) {
                                    if emojis == [] {
                                        VStack{
                                            HStack{
                                                Image("Good")
                                                    .resizable()
                                                    .frame(width: 100, height: 100)
                                                Image("Happy3")
                                                    .resizable()
                                                    .frame(width: 100, height: 100)
                                            }
                                            Text("Good Job!")
                                                .font(.title)
                                                .bold()
                                                .presentationDetents([ .medium, .large])
                                                .presentationBackground(.thinMaterial)
                                        }
                                    } else {
                                        VStack{
                                            HStack{
                                                Image("Angry2")
                                                    .resizable()
                                                    .frame(width: 100, height: 100)
                                                Image("Sad")
                                                    .resizable()
                                                    .frame(width: 100, height: 100)
                                            }
                                            Text("Oops! \nThe room is still like Kapal Pecah!")
                                                .multilineTextAlignment(.center)
                                                .font(.title)
                                                .bold()
                                                .presentationDetents([ .medium, .large])
                                                .presentationBackground(.thinMaterial)
                                        }
                                    }
                                }
                
                // Button Clean Up and Mess Up
                Button(action: {
                    emojis = []
                    emojis += ["🧸", "🎀", "🎈", "🪆", "🛍️", "📿", "🎏", "🚗","🧩", "🎮", "🎲", "⚽️", "🏀", "🏸", "🛼"]
                    
                    // Toggle
                    if start == false{
                        start = true
                        buttonText = "MESS UP AGAIN"
                        tooglePause()
                        isButtonActive = false
                    }else{
                        start = false
                        buttonText = "CLEAN UP"
                        tooglePause()
                        isButtonActive = true
                    }
                    
                    timeRemaining = 10
                }) {
                    if buttonText == "MESS UP AGAIN"{
                        Text("\(buttonText)")
                        .bold()
                        .padding(.horizontal, 100)
                        .padding(.vertical, 8)
                        .foregroundColor(.white)
                        .background(isButtonActive ? Color.green : Color.gray)
                        .cornerRadius(8)
                        
                    }
                    else if buttonText == "CLEAN UP"{
                        Text("\(buttonText)")
                        .bold()
                        .padding(.horizontal, 100)
                        .padding(.vertical, 8)
                        .foregroundColor(.white)
                        .background(isButtonActive ? Color.green : Color.gray)
                        .cornerRadius(8)
                    }
                }
                .disabled(!isButtonActive)
            }
        } // End body
    }
    
    // Functions
    func randomPoint(in rect: CGRect) -> CGPoint {
        let x = rect.minX + CGFloat.random(in: 30...350)
        let y = rect.minY + CGFloat.random(in: 0...200)
        return CGPoint(x: x, y: y)
    }
    
    func buttonTapped() {
            isButtonActive = false
            restart()
    }
    
    func stopTimer() {
           self.timer.upstream.connect().cancel()
       }
    
    func removeEmoji(_ emoji: String) {
        if let index = emojis.firstIndex(of: emoji) {
            emojis.remove(at: index)
        }
    }
    
    func restart() {
        timeRemaining = 10
    }
    
    func tooglePause() {
        if paused == true{
            paused = false
            isButtonActive = false
        } else{
            paused = true
            isButtonActive = true
        }
    }
}

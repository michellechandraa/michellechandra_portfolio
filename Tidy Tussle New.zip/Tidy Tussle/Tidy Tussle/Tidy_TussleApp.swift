//
//  Tidy_TussleApp.swift
//  Tidy Tussle
//
//  Created by michelle chandra on 17/04/23.
//

import SwiftUI

@main
struct Tidy_TussleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
